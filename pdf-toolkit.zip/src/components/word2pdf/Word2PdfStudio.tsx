import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  FileCheck,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  Maximize2,
  Compass,
  LayoutGrid,
  Hash,
  X,
  Eye,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { WordDocumentInfo, WordSettings, ConversionProgress, PageMargin } from '../../types/pdf';
import {
  validateAndParseWordFile,
  generatePdfFromWord,
  getSampleWordDocument,
} from '../../utils/wordToPdfGenerator';
import { formatBytes } from '../../utils/pdfGenerator';
import { ConversionProgressModal } from '../image2pdf/ConversionProgressModal';

interface Word2PdfStudioProps {
  onSuccess: (record: any) => void;
  onBackToHome: () => void;
}

export const Word2PdfStudio: React.FC<Word2PdfStudioProps> = ({
  onSuccess,
  onBackToHome,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [docInfo, setDocInfo] = useState<WordDocumentInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  // Conversion Progress State
  const [conversionProgress, setConversionProgress] = useState<ConversionProgress | null>(null);

  // Settings State
  const [settings, setSettings] = useState<WordSettings>({
    pageSize: 'a4',
    orientation: 'portrait',
    margin: 'medium',
    showPageNumbers: true,
    filename: 'Word_Document',
  });

  const handleAutoFilename = () => {
    const timestamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 12);
    setSettings((prev) => ({
      ...prev,
      filename: `Doc_${timestamp}`,
    }));
  };

  const handleFileChange = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const parsedInfo = await validateAndParseWordFile(file);
      setDocInfo(parsedInfo);

      // Set clean initial filename from document name
      const cleanName = file.name.replace(/\.(docx|doc)$/i, '');
      setSettings((prev) => ({
        ...prev,
        filename: cleanName || 'Word_Document',
      }));
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load and validate the Word document.');
      setDocInfo(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files);
    }
  };

  const handleLoadSample = () => {
    setErrorMessage(null);
    const sample = getSampleWordDocument();
    setDocInfo(sample);
    setSettings((prev) => ({
      ...prev,
      filename: 'Sample_Business_Report',
    }));
  };

  const handleConvert = async () => {
    if (!docInfo) return;
    setErrorMessage(null);

    if (docInfo.isLegacyDoc) {
      setErrorMessage(
        'Legacy .doc binary files cannot be automatically converted. Please convert the document to .docx in Word/Google Docs or choose a .docx file.'
      );
      return;
    }

    try {
      const result = await generatePdfFromWord(docInfo, settings, (progress) => {
        setConversionProgress(progress);
      });

      const cleanFilename = settings.filename.trim()
        ? settings.filename.endsWith('.pdf')
          ? settings.filename
          : `${settings.filename}.pdf`
        : 'Document.pdf';

      const record = {
        id: `pdf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        filename: cleanFilename,
        sizeBytes: result.sizeBytes,
        pageCount: result.pageCount,
        createdAt: Date.now(),
        blobUrl: result.blobUrl,
        blobData: result.arrayBuffer,
        thumbnailUrl: result.thumbnailUrl,
        sourceType: 'word' as const,
      };

      setTimeout(() => {
        setConversionProgress(null);
        onSuccess(record);
      }, 400);
    } catch (err: any) {
      setConversionProgress(null);
      setErrorMessage(err.message || 'Failed to convert Word document to PDF.');
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-fade-in pb-12">
      {/* File Upload / Selected Zone */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => handleFileChange(e.target.files)}
        accept=".docx,.doc,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword"
        className="hidden"
        id="input-file-word"
      />

      {!docInfo ? (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center transition-all duration-300 flex flex-col items-center justify-center min-h-[340px] backdrop-blur-md ${
            isDragging
              ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/40 scale-[0.99]'
              : 'border-slate-300 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 hover:border-blue-500 dark:hover:border-blue-400'
          }`}
        >
          <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-5 border border-blue-100 dark:border-blue-900/40">
            <FileText className="w-8 h-8 animate-pulse" />
          </div>

          <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">
            Select Word Document to Convert
          </h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6 leading-relaxed">
            Drag & drop a DOCX or DOC document here, or choose from your device. Supports text formatting, headings, bullet lists, tables, and images.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 w-full max-w-xs">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              id="btn-select-word-file"
              className="flex-1 px-6 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              <Upload className="w-4 h-4" />
              <span>Browse File</span>
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-200/80 dark:border-slate-800/80 w-full max-w-md flex flex-col items-center">
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mb-3">
              Want to test immediately without uploading?
            </p>
            <button
              onClick={handleLoadSample}
              disabled={isLoading}
              id="btn-load-sample-word"
              className="px-4 py-2 rounded-full bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50 border border-blue-200/50 dark:border-blue-800/50"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Load Sample Word Report</span>
            </button>
          </div>
        </div>
      ) : (
        /* Selected Document Card & Preview */
        <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800/80 p-6 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-12 h-14 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center shrink-0 border border-blue-100 dark:border-blue-900/40">
                <FileText className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {docInfo.name}
                </h3>
                <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-slate-500 dark:text-slate-400">
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-medium">
                    {formatBytes(docInfo.size)}
                  </span>
                  <span>•</span>
                  <span>{docInfo.wordCount} Words</span>
                  <span>•</span>
                  <span>{docInfo.paragraphCount} Paragraphs</span>
                  {docInfo.imageCount > 0 && (
                    <>
                      <span>•</span>
                      <span>{docInfo.imageCount} Images</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowPreviewModal(true)}
                id="btn-word-preview-content"
                className="px-3.5 py-2 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
              >
                <Eye className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Preview Document</span>
              </button>
              <button
                onClick={() => setDocInfo(null)}
                id="btn-change-word-document"
                className="px-3.5 py-2 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-red-950/40 hover:text-red-600 dark:hover:text-red-400 text-slate-500 dark:text-slate-400 text-xs font-semibold transition-colors border border-slate-200 dark:border-slate-700"
              >
                Change Document
              </button>
            </div>
          </div>

          {/* Document Content Quick Box */}
          <div className="bg-slate-50/80 dark:bg-slate-800/50 rounded-2xl p-5 border border-slate-200/60 dark:border-slate-700/60 max-h-48 overflow-y-auto space-y-2">
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Extracted Document Summary
            </p>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed line-clamp-4 italic">
              "{docInfo.rawText.slice(0, 350)}..."
            </p>
          </div>

          {/* PDF Output Settings Panel */}
          <div className="space-y-4 pt-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              PDF Output Options
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Page Size */}
              <div>
                <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
                  <Maximize2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  Page Size
                </label>
                <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  {(
                    [
                      ['a4', 'A4'],
                      ['letter', 'Letter'],
                      ['legal', 'Legal'],
                    ] as const
                  ).map(([value, label]) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setSettings((prev) => ({ ...prev, pageSize: value }))}
                      id={`btn-word-pagesize-${value}`}
                      className={`py-1.5 rounded-lg text-xs font-medium transition-all ${
                        settings.pageSize === value
                          ? 'bg-blue-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Orientation */}
              <div>
                <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  Orientation
                </label>
                <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  {(
                    [
                      ['portrait', 'Portrait'],
                      ['landscape', 'Landscape'],
                    ] as const
                  ).map(([value, label]) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setSettings((prev) => ({ ...prev, orientation: value }))}
                      id={`btn-word-orientation-${value}`}
                      className={`py-1.5 rounded-lg text-xs font-medium transition-all ${
                        settings.orientation === value
                          ? 'bg-blue-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Margins */}
              <div>
                <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
                  <LayoutGrid className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  Margins
                </label>
                <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  {(
                    [
                      ['none', 'None'],
                      ['small', 'Small'],
                      ['medium', 'Med'],
                      ['large', 'Large'],
                    ] as const
                  ).map(([value, label]) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setSettings((prev) => ({ ...prev, margin: value as PageMargin }))}
                      id={`btn-word-margin-${value}`}
                      className={`py-1.5 rounded-lg text-xs font-medium transition-all ${
                        settings.margin === value
                          ? 'bg-blue-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Page Numbering */}
              <div>
                <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  Page Numbers
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setSettings((prev) => ({ ...prev, showPageNumbers: !prev.showPageNumbers }))
                  }
                  id="btn-toggle-word-pagenumbers"
                  className={`w-full py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-between transition-colors ${
                    settings.showPageNumbers
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                  }`}
                >
                  <span>Footer "Page X of Y"</span>
                  <span
                    className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] text-white font-bold ${
                      settings.showPageNumbers ? 'bg-blue-600' : 'bg-slate-400 dark:bg-slate-600'
                    }`}
                  >
                    {settings.showPageNumbers ? '✓' : ''}
                  </span>
                </button>
              </div>
            </div>

            {/* Output Filename & Primary Convert Button */}
            <div className="pt-4 border-t border-slate-200/80 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="w-full sm:w-auto flex-1 max-w-md">
                <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-1">
                  Output PDF Filename
                </label>
                <div className="relative flex items-center">
                  <input
                    type="text"
                    value={settings.filename}
                    onChange={(e) => setSettings((prev) => ({ ...prev, filename: e.target.value }))}
                    placeholder="Enter PDF filename"
                    id="input-word-pdf-filename"
                    className="w-full pl-3.5 pr-20 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <span className="absolute right-10 text-xs font-medium text-slate-400 pointer-events-none">
                    .pdf
                  </span>
                  <button
                    type="button"
                    onClick={handleAutoFilename}
                    id="btn-auto-filename-word"
                    className="absolute right-2.5 p-1 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
                    title="Generate automatic timestamp filename"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <button
                onClick={handleConvert}
                id="btn-convert-word-pdf"
                className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/20 flex items-center justify-center gap-2.5 transition-all"
              >
                <FileCheck className="w-5 h-5" />
                <span>Convert Word to PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Error Alert Box */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-800 dark:text-red-300 text-xs flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold">Document Validation or Processing Issue</p>
            <p className="mt-0.5 leading-relaxed">{errorMessage}</p>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-red-600 hover:text-red-800 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Conversion Progress Modal */}
      {conversionProgress && (
        <ConversionProgressModal
          progress={conversionProgress}
          onCancel={() => setConversionProgress(null)}
        />
      )}

      {/* Live Document Preview Modal */}
      {showPreviewModal && docInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-3xl max-h-[85vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Document Preview: {docInfo.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {docInfo.wordCount} Words • {docInfo.paragraphCount} Paragraphs
                </p>
              </div>
              <button
                onClick={() => setShowPreviewModal(false)}
                id="btn-close-word-preview"
                className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-6 bg-slate-50 dark:bg-slate-950">
              <div
                className="max-w-2xl mx-auto bg-white text-slate-900 p-8 rounded-2xl shadow-sm border border-slate-200 prose prose-sm"
                dangerouslySetInnerHTML={{ __html: docInfo.htmlContent }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
