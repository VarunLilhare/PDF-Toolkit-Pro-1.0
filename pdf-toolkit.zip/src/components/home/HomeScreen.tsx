import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  ShieldCheck,
  Zap,
  FileText,
  Clock,
  ArrowRight,
  Plus,
  Eye,
  Download,
} from 'lucide-react';
import { ToolItem, ToolCategory, ViewMode, PdfDocumentRecord } from '../../types/pdf';
import { ToolCard } from './ToolCard';

interface HomeScreenProps {
  onNavigate: (view: ViewMode) => void;
  recentPdfs: PdfDocumentRecord[];
  onOpenRecord: (record: PdfDocumentRecord) => void;
  onOpenHistory: () => void;
}

const TOOLS_CATALOG: ToolItem[] = [
  // Active Tools
  {
    id: 'image2pdf',
    title: 'Image to PDF',
    description: 'Convert JPG, PNG, WebP, GIF, and BMP photos into customized PDF documents.',
    iconName: 'FileImage',
    category: 'convert-to-pdf',
    isActive: true,
    viewMode: 'IMAGE2PDF',
  },
  {
    id: 'word2pdf',
    title: 'Word to PDF',
    description: 'Convert DOCX and Word documents into crisp, formatted PDF files.',
    iconName: 'FileText',
    category: 'convert-to-pdf',
    isActive: true,
    viewMode: 'WORD2PDF',
  },

  // Future Tools (Placeholders / Coming Soon)
  {
    id: 'pdf2word',
    title: 'PDF to Word',
    description: 'Extract text and layouts from PDF documents into editable Word files.',
    iconName: 'FileType',
    category: 'convert-from-pdf',
    isActive: false,
  },
  {
    id: 'pdf2image',
    title: 'PDF to Image',
    description: 'Extract pages from PDF files and save them as high-quality JPG or PNG images.',
    iconName: 'FileImage',
    category: 'convert-from-pdf',
    isActive: false,
  },
  {
    id: 'merge-pdf',
    title: 'Merge PDF',
    description: 'Combine multiple PDF files into a single, organized PDF document.',
    iconName: 'Combine',
    category: 'edit-organize',
    isActive: false,
  },
  {
    id: 'split-pdf',
    title: 'Split PDF',
    description: 'Extract specific pages or split a PDF into separate standalone files.',
    iconName: 'Scissors',
    category: 'edit-organize',
    isActive: false,
  },
  {
    id: 'compress-pdf',
    title: 'Compress PDF',
    description: 'Reduce PDF file size while maintaining image and text resolution.',
    iconName: 'Zap',
    category: 'security-utility',
    isActive: false,
  },
  {
    id: 'rotate-pdf',
    title: 'Rotate PDF',
    description: 'Rotate individual or all pages within a PDF document by 90, 180, or 270 degrees.',
    iconName: 'RotateCw',
    category: 'edit-organize',
    isActive: false,
  },
  {
    id: 'ocr-scanner',
    title: 'OCR Text Scanner',
    description: 'Recognize and extract text from scanned images and PDFs automatically.',
    iconName: 'ScanText',
    category: 'security-utility',
    isActive: false,
  },
  {
    id: 'watermark-pdf',
    title: 'Watermark PDF',
    description: 'Stamp custom text or image watermarks onto PDF pages for privacy.',
    iconName: 'Stamp',
    category: 'edit-organize',
    isActive: false,
  },
  {
    id: 'protect-pdf',
    title: 'Password Protect',
    description: 'Encrypt PDF documents with custom passwords to prevent unauthorized viewing.',
    iconName: 'Lock',
    category: 'security-utility',
    isActive: false,
  },
  {
    id: 'unlock-pdf',
    title: 'Unlock PDF',
    description: 'Remove passwords and permissions security from PDF documents.',
    iconName: 'Unlock',
    category: 'security-utility',
    isActive: false,
  },
];

const CATEGORIES: { id: 'all' | ToolCategory; label: string }[] = [
  { id: 'all', label: 'All Tools' },
  { id: 'convert-to-pdf', label: 'Convert to PDF' },
  { id: 'convert-from-pdf', label: 'Convert from PDF' },
  { id: 'edit-organize', label: 'Edit & Organize' },
  { id: 'security-utility', label: 'Security & Utilities' },
];

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  recentPdfs,
  onOpenRecord,
  onOpenHistory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | ToolCategory>('all');

  // Filter tools based on category and search query
  const filteredTools = TOOLS_CATALOG.filter((tool) => {
    const matchesCategory = activeCategory === 'all' || tool.category === activeCategory;
    const matchesSearch =
      tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleSelectTool = (tool: ToolItem) => {
    if (tool.viewMode) {
      onNavigate(tool.viewMode);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* 1. PDF Tools & Utilities Section (MOVED TO TOP) */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              PDF Tools & Utilities
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select a tool to convert, edit, or process your documents.
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search PDF tools..."
              id="input-search-tools"
              className="w-full pl-9 pr-4 py-2 rounded-full border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xs text-slate-900 dark:text-slate-100 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-600 shadow-2xs"
            />
          </div>
        </div>

        {/* Filter Category Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              id={`btn-category-${cat.id}`}
              className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat.id
                  ? 'bg-blue-600 text-white font-semibold shadow-xs shadow-blue-500/20'
                  : 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-xs border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Tools Responsive Grid */}
        {filteredTools.length === 0 ? (
          <div className="text-center py-12 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm rounded-3xl border border-slate-200 dark:border-slate-800 p-8 space-y-2">
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              No tools match "{searchQuery}"
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Try searching with keywords like "Word", "Image", "Merge", or "Password".
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} onSelect={handleSelectTool} />
            ))}
          </div>
        )}
      </div>

      {/* 2. Recent PDF Documents Section (MIDDLE) */}
      {recentPdfs.length > 0 && (
        <div className="space-y-3 pt-4 border-t border-slate-200/80 dark:border-slate-800/80">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              Recent Documents
            </h3>
            <button
              onClick={onOpenHistory}
              id="btn-home-view-all-history"
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
            >
              View All ({recentPdfs.length}) <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {recentPdfs.slice(0, 3).map((item) => (
              <div
                key={item.id}
                onClick={() => onOpenRecord(item)}
                className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm rounded-2xl p-3.5 border border-slate-200/80 dark:border-slate-800/80 flex items-center gap-3 hover:border-blue-500 dark:hover:border-blue-400 cursor-pointer transition-colors shadow-2xs"
              >
                <div className="w-10 h-12 bg-blue-50 dark:bg-blue-950/60 rounded-xl flex items-center justify-center shrink-0 overflow-hidden border border-blue-100 dark:border-blue-900/40">
                  {item.thumbnailUrl ? (
                    <img src={item.thumbnailUrl} alt={item.filename} className="w-full h-full object-cover" />
                  ) : (
                    <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {item.filename}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {item.pageCount} {item.pageCount === 1 ? 'Page' : 'Pages'} • {new Date(item.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <button
                  className="p-1.5 rounded-full text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60"
                  title="View PDF"
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Trust & Local Processing Feature Highlights (MOVED TO BOTTOM) */}
      <div className="pt-4 border-t border-slate-200/80 dark:border-slate-800/80 space-y-3">
        <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
          Platform Architecture & Privacy
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800/80 flex items-start gap-3 shadow-2xs">
            <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">100% Client-Side Privacy</h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Files remain strictly on your local device. Zero server file uploads.
              </p>
            </div>
          </div>

          <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800/80 flex items-start gap-3 shadow-2xs">
            <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Instant Conversion</h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                High-speed Canvas & Mammoth JS engines for instant offline rendering.
              </p>
            </div>
          </div>

          <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm rounded-2xl p-4 border border-slate-200/80 dark:border-slate-800/80 flex items-start gap-3 shadow-2xs">
            <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Compliant PDF Spec</h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Validated %PDF- magic headers with custom margins and page numbers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
