import React from 'react';
import {
  FileText,
  FileImage,
  FileSpreadsheet,
  FileType,
  Sparkles,
  Combine,
  Scissors,
  Zap,
  RotateCw,
  Lock,
  Unlock,
  Eye,
  ScanText,
  ArrowRight,
  Stamp,
} from 'lucide-react';
import { ToolItem } from '../../types/pdf';

interface ToolCardProps {
  tool: ToolItem;
  onSelect: (tool: ToolItem) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  FileImage,
  FileText,
  FileSpreadsheet,
  FileType,
  Combine,
  Scissors,
  Zap,
  RotateCw,
  Stamp,
  Lock,
  Unlock,
  Eye,
  ScanText,
};

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onSelect }) => {
  const IconComponent = ICON_MAP[tool.iconName] || FileText;

  return (
    <div
      onClick={() => tool.isActive && onSelect(tool)}
      id={`tool-card-${tool.id}`}
      className={`group relative rounded-2xl p-5 border transition-all duration-200 flex flex-col justify-between ${
        tool.isActive
          ? 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-slate-200/80 dark:border-slate-800/80 hover:border-blue-500 dark:hover:border-blue-400 cursor-pointer hover:shadow-lg hover:shadow-blue-500/5'
          : 'bg-slate-100/50 dark:bg-slate-900/30 border-slate-200/50 dark:border-slate-800/50 opacity-60 cursor-not-allowed'
      }`}
    >
      <div>
        {/* Top Icon & Badge Row */}
        <div className="flex items-center justify-between mb-4">
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-colors ${
              tool.isActive
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white dark:group-hover:bg-blue-500'
                : 'bg-slate-200/60 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400'
            }`}
          >
            <IconComponent className="w-5 h-5" />
          </div>

          {tool.isActive ? (
            <span className="px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-[11px] font-semibold flex items-center gap-1 border border-blue-200/50 dark:border-blue-800/50">
              <Sparkles className="w-3 h-3 text-blue-600 dark:text-blue-400" /> Active
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-[11px] font-medium border border-slate-200/50 dark:border-slate-700/50">
              Coming Soon
            </span>
          )}
        </div>

        {/* Title & Description */}
        <h3
          className={`text-base font-bold mb-1.5 transition-colors ${
            tool.isActive
              ? 'text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          {tool.title}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">
          {tool.description}
        </p>
      </div>

      {/* Bottom Action Footer */}
      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-medium">
        {tool.isActive ? (
          <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1 font-semibold group-hover:translate-x-1 transition-transform">
            Open Tool <ArrowRight className="w-3.5 h-3.5" />
          </span>
        ) : (
          <span className="text-slate-400 dark:text-slate-500 italic">In Roadmap</span>
        )}
      </div>
    </div>
  );
};
