import React, { useState } from 'react';
import {
  Moon,
  Sun,
  HardDrive,
  Trash2,
  Check,
  Maximize2,
  LayoutGrid,
  Zap,
  Info,
  RefreshCw,
} from 'lucide-react';
import { clearAllPdfsFromStorage } from '../../utils/storage';

interface SettingsScreenProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  historyCount: number;
  onHistoryCleared: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  darkMode,
  onToggleDarkMode,
  historyCount,
  onHistoryCleared,
}) => {
  const [isClearing, setIsClearing] = useState(false);
  const [clearedSuccess, setClearedSuccess] = useState(false);

  const handleClearHistory = async () => {
    if (historyCount === 0) return;
    if (!window.confirm('Are you sure you want to delete all saved PDF history from local storage?')) {
      return;
    }

    setIsClearing(true);
    try {
      await clearAllPdfsFromStorage();
      onHistoryCleared();
      setClearedSuccess(true);
      setTimeout(() => setClearedSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to clear storage:', err);
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-fade-in pb-16">
      <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800/80 p-6 sm:p-8 space-y-8 shadow-sm">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            App Preferences & Settings
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Configure default settings, theme, and local document storage.
          </p>
        </div>

        {/* Theme Settings */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Appearance
          </h3>
          <div className="bg-slate-50/80 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                {darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5 text-amber-500" />}
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">Dark Theme</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Toggle between Nordic Slate Dark and Clean Glassmorphic Light themes.
                </p>
              </div>
            </div>

            <button
              onClick={onToggleDarkMode}
              id="btn-settings-toggle-theme"
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                darkMode ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  darkMode ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Local Storage & Cache */}
        <div className="space-y-4 pt-4 border-t border-slate-200/80 dark:border-slate-800/80">
          <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Local Document Storage
          </h3>
          <div className="bg-slate-50/80 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                  <HardDrive className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">IndexedDB History Storage</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Currently storing <span className="font-semibold text-blue-600 dark:text-blue-400">{historyCount}</span> generated PDF document{historyCount === 1 ? '' : 's'}.
                  </p>
                </div>
              </div>

              <button
                onClick={handleClearHistory}
                disabled={historyCount === 0 || isClearing}
                id="btn-settings-clear-storage"
                className="px-4 py-2 rounded-full bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/50 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear Storage</span>
              </button>
            </div>

            {clearedSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 font-medium">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>All PDF documents cleared from browser storage.</span>
              </div>
            )}
          </div>
        </div>

        {/* About App */}
        <div className="space-y-4 pt-4 border-t border-slate-200/80 dark:border-slate-800/80">
          <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            About App
          </h3>
          <div className="bg-slate-50/80 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-500 dark:text-slate-400">Version</span>
              <span className="font-bold text-slate-900 dark:text-slate-100">v2.1.0 Pro</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-500 dark:text-slate-400">Engine</span>
              <span className="font-bold text-slate-900 dark:text-slate-100">Client Canvas + Mammoth JS</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-500 dark:text-slate-400">PDF Specification</span>
              <span className="font-bold text-slate-900 dark:text-slate-100">%PDF-1.4 Binary Specification</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
