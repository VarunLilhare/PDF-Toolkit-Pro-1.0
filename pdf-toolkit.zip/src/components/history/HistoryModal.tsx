import React, { useState } from 'react';
import { X, FileText, Eye, Download, Trash2, Edit2, Share2, Search } from 'lucide-react';
import { PdfDocumentRecord } from '../../types/pdf';
import { formatBytes } from '../../utils/pdfGenerator';

interface HistoryModalProps {
  records: PdfDocumentRecord[];
  onClose: () => void;
  onOpenRecord: (record: PdfDocumentRecord) => void;
  onDownloadRecord: (record: PdfDocumentRecord) => void;
  onShareRecord: (record: PdfDocumentRecord) => void;
  onRenameRecord: (id: string, newFilename: string) => void;
  onDeleteRecord: (id: string) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  records,
  onClose,
  onOpenRecord,
  onDownloadRecord,
  onShareRecord,
  onRenameRecord,
  onDeleteRecord,
}) => {
  const [search, setSearch] = useState('');
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');

  const filtered = records.filter((r) =>
    r.filename.toLowerCase().includes(search.toLowerCase())
  );

  const startRename = (record: PdfDocumentRecord) => {
    setRenamingId(record.id);
    setRenameValue(record.filename);
  };

  const handleSaveRename = (id: string) => {
    if (renameValue.trim()) {
      onRenameRecord(id, renameValue.trim());
      setRenamingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#111412]/70 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[85vh] bg-white dark:bg-[#1A1D1A] rounded-3xl border border-[#E1E3DF] dark:border-[#2D322C] overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#E1E3DF] dark:border-[#2D322C]">
          <div>
            <h3 className="text-lg font-semibold text-[#191C19] dark:text-[#E2E6DF]">
              My PDF Documents
            </h3>
            <p className="text-xs text-[#747972] dark:text-[#9EA39B]">
              {records.length} {records.length === 1 ? 'file' : 'files'} saved in local storage
            </p>
          </div>

          <button
            onClick={onClose}
            id="btn-close-history"
            className="p-2 rounded-full hover:bg-[#F1F3EE] dark:hover:bg-[#222622] text-[#747972] dark:text-[#9EA39B]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        {records.length > 0 && (
          <div className="p-4 border-b border-[#E1E3DF] dark:border-[#2D322C] bg-[#F1F3EE]/50 dark:bg-[#222622]/50">
            <div className="relative flex items-center">
              <Search className="w-4 h-4 text-[#747972] dark:text-[#9EA39B] absolute left-3.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search PDF files..."
                id="input-search-history"
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#E1E3DF] dark:border-[#2D322C] bg-white dark:bg-[#1A1D1A] text-[#191C19] dark:text-[#E2E6DF] text-xs font-medium focus:outline-none focus:ring-2 focus:ring-[#006C4C]"
              />
            </div>
          </div>
        )}

        {/* Document List */}
        <div className="flex-1 overflow-auto p-4 space-y-3">
          {records.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-[#F1F3EE] dark:bg-[#222622] text-[#747972] dark:text-[#9EA39B] flex items-center justify-center mx-auto">
                <FileText className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-[#191C19] dark:text-[#E2E6DF]">
                No PDFs created yet
              </p>
              <p className="text-xs text-[#747972] dark:text-[#9EA39B] max-w-xs mx-auto">
                Convert your images to PDF and they will automatically appear here for offline access.
              </p>
            </div>
          ) : filtered.length === 0 ? (
            <p className="text-center py-8 text-xs text-[#747972] dark:text-[#9EA39B]">
              No matching files found.
            </p>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="bg-[#F1F3EE] dark:bg-[#222622] rounded-2xl p-3.5 border border-[#E1E3DF] dark:border-[#2D322C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:border-[#006C4C] dark:hover:border-[#008760] transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div
                    onClick={() => onOpenRecord(item)}
                    className="w-10 h-12 bg-[#DDEEE3] dark:bg-[#14382B] text-[#006C4C] dark:text-[#A8F0D3] rounded-xl flex items-center justify-center shrink-0 cursor-pointer overflow-hidden relative group"
                  >
                    {item.thumbnailUrl ? (
                      <img
                        src={item.thumbnailUrl}
                        alt=""
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <FileText className="w-5 h-5" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    {renamingId === item.id ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          id={`input-rename-history-${item.id}`}
                          className="px-2 py-1 rounded-lg border border-[#006C4C] bg-white dark:bg-[#1A1D1A] text-xs font-semibold"
                        />
                        <button
                          onClick={() => handleSaveRename(item.id)}
                          id={`btn-save-rename-history-${item.id}`}
                          className="px-2.5 py-1 rounded-full bg-[#006C4C] text-white text-[11px] font-semibold"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <h4
                          onClick={() => onOpenRecord(item)}
                          className="text-xs font-semibold text-[#191C19] dark:text-[#E2E6DF] truncate cursor-pointer hover:text-[#006C4C] dark:hover:text-[#A8F0D3]"
                        >
                          {item.filename}
                        </h4>
                        <button
                          onClick={() => startRename(item)}
                          id={`btn-start-rename-${item.id}`}
                          className="p-1 text-[#747972] dark:text-[#9EA39B] hover:text-[#006C4C] dark:hover:text-[#A8F0D3]"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}

                    <p className="text-[11px] text-[#747972] dark:text-[#9EA39B] mt-0.5">
                      {item.pageCount} {item.pageCount === 1 ? 'Page' : 'Pages'} • {formatBytes(item.sizeBytes)} •{' '}
                      {new Date(item.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 self-end sm:self-center">
                  <button
                    onClick={() => onOpenRecord(item)}
                    id={`btn-history-open-${item.id}`}
                    className="p-2 rounded-full bg-white dark:bg-[#1A1D1A] hover:bg-[#DDEEE3] dark:hover:bg-[#14382B] text-[#006C4C] dark:text-[#A8F0D3] border border-[#E1E3DF] dark:border-[#2D322C] transition-colors"
                    title="View PDF"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDownloadRecord(item)}
                    id={`btn-history-download-${item.id}`}
                    className="p-2 rounded-full bg-white dark:bg-[#1A1D1A] hover:bg-[#F1F3EE] dark:hover:bg-[#222622] text-[#191C19] dark:text-[#E2E6DF] border border-[#E1E3DF] dark:border-[#2D322C] transition-colors"
                    title="Download"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onShareRecord(item)}
                    id={`btn-history-share-${item.id}`}
                    className="p-2 rounded-full bg-white dark:bg-[#1A1D1A] hover:bg-[#F1F3EE] dark:hover:bg-[#222622] text-[#191C19] dark:text-[#E2E6DF] border border-[#E1E3DF] dark:border-[#2D322C] transition-colors"
                    title="Share"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDeleteRecord(item.id)}
                    id={`btn-history-delete-${item.id}`}
                    className="p-2 rounded-full bg-white dark:bg-[#1A1D1A] hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 text-[#747972] border border-[#E1E3DF] dark:border-[#2D322C] transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
