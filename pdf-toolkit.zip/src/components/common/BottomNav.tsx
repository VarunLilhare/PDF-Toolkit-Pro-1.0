import React from 'react';
import { Home, Info, Settings } from 'lucide-react';
import { ViewMode } from '../../types/pdf';

interface BottomNavProps {
  currentView: ViewMode;
  onNavigate: (view: ViewMode) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate }) => {
  const tabs = [
    {
      id: 'HOME' as ViewMode,
      label: 'Home',
      icon: Home,
    },
    {
      id: 'INFO' as ViewMode,
      label: 'Info',
      icon: Info,
    },
    {
      id: 'SETTINGS' as ViewMode,
      label: 'Settings',
      icon: Settings,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800/80 py-2.5 px-4 shadow-lg shadow-slate-900/5">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive =
            tab.id === 'HOME'
              ? currentView === 'HOME' ||
                currentView === 'IMAGE2PDF' ||
                currentView === 'WORD2PDF' ||
                currentView === 'STUDIO' ||
                currentView === 'SUCCESS'
              : currentView === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              id={`nav-tab-${tab.id.toLowerCase()}`}
              className={`flex flex-col items-center justify-center py-1.5 px-6 rounded-2xl transition-all duration-200 min-w-[76px] ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-semibold scale-105 border border-blue-200/50 dark:border-blue-800/50'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              <span className="text-[11px] tracking-wide">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

