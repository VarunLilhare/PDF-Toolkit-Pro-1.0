import React from 'react';
import { FileText, History, Moon, Sun, ArrowLeft } from 'lucide-react';

interface TopBarProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  onOpenHistory?: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  historyCount?: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  subtitle,
  showBack,
  onBack,
  onOpenHistory,
  darkMode,
  onToggleDarkMode,
  historyCount = 0,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md px-6 py-3.5 transition-colors duration-200 shadow-xs">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          {showBack && (
            <button
              onClick={onBack}
              id="btn-back-home"
              className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 transition-colors"
              title="Go back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 dark:bg-blue-500 flex items-center justify-center text-white shadow-sm shadow-blue-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 dark:text-slate-100 leading-tight">
                {title}
              </h1>
              {subtitle && (
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {onOpenHistory && (
            <button
              onClick={onOpenHistory}
              id="btn-open-history"
              className="relative flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700/80 text-slate-800 dark:text-slate-200 text-xs font-medium transition-colors border border-slate-200/50 dark:border-slate-700/50"
              title="Recent PDFs"
            >
              <History className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="hidden sm:inline">My PDFs</span>
              {historyCount > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 rounded-full bg-blue-600 text-white text-[10px] font-bold">
                  {historyCount}
                </span>
              )}
            </button>
          )}

          <button
            onClick={onToggleDarkMode}
            id="btn-toggle-theme"
            className="p-2 rounded-full bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700/80 text-slate-800 dark:text-slate-200 transition-colors border border-slate-200/50 dark:border-slate-700/50"
            title="Toggle theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>
        </div>
      </div>
    </header>
  );
};

