import React from 'react';
import { X, Download, Printer, Share2, FileText, Maximize2 } from 'lucide-react';
import { PdfDocumentRecord } from '../../types/pdf';
import { formatBytes } from '../../utils/pdfGenerator';

interface PdfViewerModalProps {
  record: PdfDocumentRecord | null;
  onClose: () => void;
  onDownload: () => void;
  onShare: () => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  record,
  onClose,
  onDownload,
  onShare,
}) => {
  if (!record || !record.blobUrl) return null;

  const handlePrint = () => {
    const printWindow = window.open(record.blobUrl, '_blank');
    if (printWindow) {
      printWindow.focus();
      printWindow.print();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-5xl h-[92vh] bg-slate-900 rounded-3xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col">
        {/* Top Viewer Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md text-white">
          <div className="flex items-center gap-2.5 truncate max-w-sm sm:max-w-md">
            <div className="p-1.5 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-900/40">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-semibold truncate text-slate-100">{record.filename}</h3>
              <p className="text-[10px] text-slate-400">
                {record.pageCount} {record.pageCount === 1 ? 'Page' : 'Pages'} • {formatBytes(record.sizeBytes)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              id="btn-viewer-print"
              className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
              title="Print PDF"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={onShare}
              id="btn-viewer-share"
              className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
              title="Share PDF"
            >
              <Share2 className="w-4 h-4 text-blue-400" />
            </button>

            <button
              onClick={onDownload}
              id="btn-viewer-download"
              className="px-4 py-1.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
              title="Download PDF"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Save</span>
            </button>

            <button
              onClick={onClose}
              id="btn-close-pdf-viewer"
              className="p-2 rounded-full bg-slate-800 hover:bg-red-900/40 text-slate-200 hover:text-red-400 transition-colors border border-slate-700 ml-1"
              title="Close viewer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Embedded PDF Viewer iFrame */}
        <div className="flex-1 bg-slate-950 relative overflow-hidden">
          <iframe
            src={`${record.blobUrl}#toolbar=1&navpanes=0`}
            title={record.filename}
            className="w-full h-full border-none"
          />
        </div>
      </div>
    </div>
  );
};
