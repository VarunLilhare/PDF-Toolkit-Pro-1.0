import React, { useState } from 'react';
import {
  CheckCircle2,
  FileText,
  Download,
  Share2,
  Eye,
  Edit2,
  Trash2,
  Home,
  Plus,
  Sparkles,
} from 'lucide-react';
import { PdfDocumentRecord } from '../../types/pdf';
import { formatBytes } from '../../utils/pdfGenerator';

interface SuccessViewProps {
  record: PdfDocumentRecord;
  onOpenViewer: () => void;
  onDownload: () => void;
  onShare: () => void;
  onRename: (newFilename: string) => void;
  onDelete: () => void;
  onReset: () => void;
}

export const SuccessView: React.FC<SuccessViewProps> = ({
  record,
  onOpenViewer,
  onDownload,
  onShare,
  onRename,
  onDelete,
  onReset,
}) => {
  const [isRenaming, setIsRenaming] = useState(false);
  const [newFilename, setNewFilename] = useState(record.filename);

  const handleSaveRename = () => {
    if (newFilename.trim()) {
      onRename(newFilename.trim());
      setIsRenaming(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 animate-fade-in py-4">
      {/* Success Badge Banner */}
      <div className="bg-blue-600 dark:bg-blue-700 rounded-3xl p-6 sm:p-8 text-white text-center relative overflow-hidden shadow-lg shadow-blue-600/20">
        <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center mx-auto mb-4 border border-white/30">
          <CheckCircle2 className="w-10 h-10 text-white" />
        </div>

        <h2 className="text-2xl font-bold mb-1">PDF Created Successfully!</h2>
        <p className="text-blue-100 text-xs sm:text-sm max-w-md mx-auto">
          Your document has been compiled, formatted, and saved locally in your browser.
        </p>
      </div>

      {/* Document Details Card */}
      <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800/80 p-6 space-y-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-center gap-5">
          {/* Thumbnail Preview */}
          {record.thumbnailUrl ? (
            <div
              onClick={onOpenViewer}
              className="w-28 h-36 bg-slate-100 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex items-center justify-center cursor-pointer group shrink-0 relative"
            >
              <img
                src={record.thumbnailUrl}
                alt={record.filename}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-blue-600/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                <Eye className="w-6 h-6" />
              </div>
            </div>
          ) : (
            <div className="w-28 h-36 bg-blue-50 dark:bg-blue-950/60 rounded-2xl border border-blue-200 dark:border-blue-900/60 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
              <FileText className="w-12 h-12" />
            </div>
          )}

          {/* Details */}
          <div className="flex-1 text-center sm:text-left space-y-2">
            {!isRenaming ? (
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 truncate max-w-xs">
                  {record.filename}
                </h3>
                <button
                  onClick={() => setIsRenaming(true)}
                  id="btn-edit-rename-pdf"
                  className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                  title="Rename PDF"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newFilename}
                  onChange={(e) => setNewFilename(e.target.value)}
                  id="input-rename-pdf-dialog"
                  className="px-3 py-1.5 rounded-xl border border-blue-600 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs font-semibold focus:outline-none"
                />
                <button
                  onClick={handleSaveRename}
                  id="btn-save-rename-pdf"
                  className="px-3.5 py-1.5 rounded-full bg-blue-600 text-white text-xs font-semibold shadow-xs"
                >
                  Save
                </button>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-medium">
                {record.pageCount} {record.pageCount === 1 ? 'Page' : 'Pages'}
              </span>
              <span>•</span>
              <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-medium">
                {formatBytes(record.sizeBytes)}
              </span>
              <span>•</span>
              <span>{new Date(record.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>

            <p className="text-xs text-blue-600 dark:text-blue-400 font-semibold flex items-center justify-center sm:justify-start gap-1 pt-1">
              <Sparkles className="w-3.5 h-3.5" /> Structure Verified (%PDF- magic header match)
            </p>
          </div>
        </div>

        {/* Primary Action Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-200/80 dark:border-slate-800/80">
          <button
            onClick={onOpenViewer}
            id="btn-success-open-pdf"
            className="px-4 py-3 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-xs"
          >
            <Eye className="w-4 h-4" />
            <span>Open PDF</span>
          </button>

          <button
            onClick={onDownload}
            id="btn-success-download-pdf"
            className="px-4 py-3 rounded-full bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all border border-slate-900 dark:border-slate-700"
          >
            <Download className="w-4 h-4" />
            <span>Save / Download</span>
          </button>

          <button
            onClick={onShare}
            id="btn-success-share-pdf"
            className="col-span-2 sm:col-span-1 px-4 py-3 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-semibold text-xs flex items-center justify-center gap-2 transition-all border border-slate-200 dark:border-slate-700"
          >
            <Share2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>Share</span>
          </button>
        </div>

        {/* Secondary Row */}
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={onDelete}
            id="btn-success-delete-pdf"
            className="px-3.5 py-1.5 rounded-full hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 dark:text-red-400 font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>

          <button
            onClick={onReset}
            id="btn-convert-another-pdf"
            className="px-4 py-2 rounded-full bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-semibold text-xs flex items-center gap-1.5 transition-colors border border-blue-200/50 dark:border-blue-800/50"
          >
            <Plus className="w-4 h-4" />
            <span>Convert More</span>
          </button>
        </div>
      </div>
    </div>
  );
};
