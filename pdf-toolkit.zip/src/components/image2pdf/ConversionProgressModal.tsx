import React from 'react';
import { Loader2, FileCheck, X } from 'lucide-react';
import { ConversionProgress } from '../../types/pdf';

interface ConversionProgressModalProps {
  progress: ConversionProgress;
  onCancel?: () => void;
}

export const ConversionProgressModal: React.FC<ConversionProgressModalProps> = ({
  progress,
  onCancel,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#111412]/70 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-md bg-white dark:bg-[#1A1D1A] rounded-3xl border border-[#E1E3DF] dark:border-[#2D322C] p-6 shadow-2xl space-y-6 text-center">
        <div className="relative w-16 h-16 mx-auto flex items-center justify-center rounded-2xl bg-[#DDEEE3] dark:bg-[#14382B] text-[#006C4C] dark:text-[#A8F0D3]">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>

        <div>
          <h3 className="text-lg font-semibold text-[#191C19] dark:text-[#E2E6DF]">
            Converting Images to PDF
          </h3>
          <p className="text-xs text-[#747972] dark:text-[#9EA39B] mt-1">
            {progress.message}
          </p>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-medium text-[#191C19] dark:text-[#E2E6DF] px-1">
            <span>Progress</span>
            <span>{progress.percentage}%</span>
          </div>

          <div className="w-full h-3 bg-[#F1F3EE] dark:bg-[#222622] rounded-full overflow-hidden p-0.5 border border-[#E1E3DF] dark:border-[#2D322C]">
            <div
              style={{ width: `${progress.percentage}%` }}
              className="h-full bg-[#006C4C] dark:bg-[#008760] rounded-full transition-all duration-300"
            />
          </div>
        </div>

        {onCancel && (
          <button
            onClick={onCancel}
            id="btn-cancel-conversion"
            className="px-4 py-2 rounded-full bg-[#F1F3EE] dark:bg-[#222622] hover:bg-[#E1E3DF] dark:hover:bg-[#2D322C] text-[#191C19] dark:text-[#E2E6DF] text-xs font-medium transition-colors inline-flex items-center gap-1.5 border border-[#E1E3DF] dark:border-[#2D322C]"
          >
            <X className="w-3.5 h-3.5" />
            <span>Cancel Conversion</span>
          </button>
        )}
      </div>
    </div>
  );
};
