import React from 'react';
import { RotateCw, Trash2, ArrowLeft, ArrowRight, Eye, Plus, RefreshCw } from 'lucide-react';
import { ImageItem } from '../../types/pdf';
import { formatBytes } from '../../utils/pdfGenerator';

interface ImageGridProps {
  images: ImageItem[];
  onReorder: (newImages: ImageItem[]) => void;
  onRotate: (id: string) => void;
  onRemove: (id: string) => void;
  onPreview: (image: ImageItem) => void;
  onAddMore: () => void;
  onClearAll: () => void;
}

export const ImageGrid: React.FC<ImageGridProps> = ({
  images,
  onReorder,
  onRotate,
  onRemove,
  onPreview,
  onAddMore,
  onClearAll,
}) => {
  const moveImage = (index: number, direction: 'left' | 'right') => {
    const newIdx = direction === 'left' ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= images.length) return;

    const updated = [...images];
    const temp = updated[index];
    updated[index] = updated[newIdx];
    updated[newIdx] = temp;
    onReorder(updated);
  };

  return (
    <div className="w-full space-y-4">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1A1D1A] p-4 sm:p-5 rounded-2xl border border-[#E1E3DF] dark:border-[#2D322C]">
        <div>
          <h2 className="text-base font-semibold text-[#191C19] dark:text-[#E2E6DF] flex items-center gap-2">
            <span>Selected Images</span>
            <span className="px-2.5 py-0.5 rounded-full bg-[#DDEEE3] dark:bg-[#14382B] text-[#002114] dark:text-[#A8F0D3] text-xs font-semibold">
              {images.length} {images.length === 1 ? 'Page' : 'Pages'}
            </span>
          </h2>
          <p className="text-xs text-[#747972] dark:text-[#9EA39B] mt-0.5">
            Arrange page order, rotate, or remove unwanted scans.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onAddMore}
            id="btn-add-more-images"
            className="px-4 py-2 rounded-full bg-[#006C4C] hover:bg-[#00533A] text-white font-medium text-xs flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Add More</span>
          </button>

          <button
            onClick={onClearAll}
            id="btn-clear-all-images"
            className="px-3.5 py-2 rounded-full bg-[#F1F3EE] dark:bg-[#222622] hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 dark:hover:text-red-400 text-[#747972] dark:text-[#9EA39B] font-medium text-xs flex items-center gap-1.5 transition-colors border border-[#E1E3DF] dark:border-[#2D322C]"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        </div>
      </div>

      {/* Grid of Image Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {images.map((item, index) => {
          const rotation = item.rotation % 360;

          return (
            <div
              key={item.id}
              className="group relative bg-white dark:bg-[#1A1D1A] rounded-2xl border border-[#E1E3DF] dark:border-[#2D322C] overflow-hidden hover:border-[#006C4C] dark:hover:border-[#008760] transition-all duration-200 flex flex-col"
            >
              {/* Page Number Badge */}
              <div className="absolute top-2.5 left-2.5 z-10 px-2 py-0.5 rounded-md bg-[#006C4C] text-white text-[11px] font-bold shadow-xs">
                {index + 1}
              </div>

              {/* Action Toolbar on Hover / Mobile */}
              <div className="absolute top-2.5 right-2.5 z-10 flex items-center gap-1">
                <button
                  onClick={() => onRotate(item.id)}
                  id={`btn-rotate-${index}`}
                  className="p-1.5 rounded-full bg-white/90 dark:bg-[#222622]/90 hover:bg-[#006C4C] hover:text-white dark:hover:bg-[#008760] text-[#191C19] dark:text-[#E2E6DF] border border-[#E1E3DF] dark:border-[#2D322C] transition-colors shadow-xs"
                  title="Rotate 90°"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onRemove(item.id)}
                  id={`btn-remove-${index}`}
                  className="p-1.5 rounded-full bg-white/90 dark:bg-[#222622]/90 hover:bg-red-600 hover:text-white text-[#191C19] dark:text-[#E2E6DF] border border-[#E1E3DF] dark:border-[#2D322C] transition-colors shadow-xs"
                  title="Remove image"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Thumbnail Container */}
              <div
                onClick={() => onPreview(item)}
                className="relative w-full h-44 bg-[#F1F3EE] dark:bg-[#111412] flex items-center justify-center overflow-hidden cursor-pointer p-3"
              >
                <img
                  src={item.src}
                  alt={item.name}
                  style={{
                    transform: `rotate(${rotation}deg)`,
                  }}
                  className="max-h-full max-w-full object-contain transition-transform duration-300 drop-shadow-xs"
                />

                <div className="absolute inset-0 bg-[#006C4C]/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="px-3 py-1.5 rounded-full bg-white text-[#006C4C] text-xs font-semibold flex items-center gap-1 shadow-md">
                    <Eye className="w-3.5 h-3.5 text-[#006C4C]" /> Preview
                  </span>
                </div>
              </div>

              {/* Bottom Metadata & Reorder Actions */}
              <div className="p-3 border-t border-[#E1E3DF] dark:border-[#2D322C] bg-white dark:bg-[#1A1D1A] mt-auto">
                <p className="text-xs font-medium text-[#191C19] dark:text-[#E2E6DF] truncate">
                  {item.name}
                </p>
                <p className="text-[10px] text-[#747972] dark:text-[#9EA39B] mt-0.5">
                  {item.width}×{item.height} • {formatBytes(item.size)}
                  {rotation > 0 && ` • ${rotation}°`}
                </p>

                {/* Reorder Buttons */}
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#F1F3EE] dark:border-[#222622]">
                  <button
                    onClick={() => moveImage(index, 'left')}
                    disabled={index === 0}
                    id={`btn-move-left-${index}`}
                    className="p-1 rounded-md text-[#747972] dark:text-[#9EA39B] hover:bg-[#F1F3EE] dark:hover:bg-[#222622] disabled:opacity-30 transition-colors"
                    title="Move earlier"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>

                  <span className="text-[10px] font-mono text-[#747972] dark:text-[#9EA39B]">
                    {index + 1} / {images.length}
                  </span>

                  <button
                    onClick={() => moveImage(index, 'right')}
                    disabled={index === images.length - 1}
                    id={`btn-move-right-${index}`}
                    className="p-1 rounded-md text-[#747972] dark:text-[#9EA39B] hover:bg-[#F1F3EE] dark:hover:bg-[#222622] disabled:opacity-30 transition-colors"
                    title="Move later"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
