import React from 'react';
import {
  Settings,
  FileCheck,
  Maximize2,
  Compass,
  LayoutGrid,
  Zap,
  Hash,
  FileSpreadsheet,
  RotateCcw,
} from 'lucide-react';
import {
  PdfSettings,
  PageSize,
  PageOrientation,
  PageMargin,
  ImageScaling,
  ImageCompression,
} from '../../types/pdf';

interface PdfSettingsPanelProps {
  settings: PdfSettings;
  onChange: (newSettings: PdfSettings) => void;
  onConvert: () => void;
  totalImages: number;
}

export const PdfSettingsPanel: React.FC<PdfSettingsPanelProps> = ({
  settings,
  onChange,
  onConvert,
  totalImages,
}) => {
  const updateSetting = <K extends keyof PdfSettings>(
    key: K,
    value: PdfSettings[K]
  ) => {
    onChange({ ...settings, [key]: value });
  };

  const handleAutoFilename = () => {
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const timeStr = now.toTimeString().slice(0, 8).replace(/:/g, '');
    updateSetting('filename', `IMG_PDF_${dateStr}_${timeStr}`);
  };

  return (
    <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800/80 p-5 sm:p-6 space-y-6 shadow-sm">
      <div className="flex items-center justify-between pb-4 border-b border-slate-200/80 dark:border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-900/40">
            <Settings className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              PDF Options
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Customize page layout, compression, margins & filename
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Page Size */}
        <div>
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
            <Maximize2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Page Size
          </label>
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            {(
              [
                ['a4', 'A4 Standard'],
                ['letter', 'US Letter'],
                ['legal', 'US Legal'],
                ['fit', 'Fit to Image'],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => updateSetting('pageSize', value as PageSize)}
                id={`btn-pagesize-${value}`}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  settings.pageSize === value
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Page Orientation */}
        <div>
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Orientation
          </label>
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            {(
              [
                ['auto', 'Auto'],
                ['portrait', 'Portrait'],
                ['landscape', 'Landscape'],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                disabled={settings.pageSize === 'fit'}
                onClick={() => updateSetting('orientation', value as PageOrientation)}
                id={`btn-orientation-${value}`}
                className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-all disabled:opacity-40 ${
                  settings.orientation === value
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Page Margins */}
        <div>
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
            <LayoutGrid className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Margins
          </label>
          <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            {(
              [
                ['none', 'None'],
                ['small', 'Small'],
                ['medium', 'Med'],
                ['large', 'Large'],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => updateSetting('margin', value as PageMargin)}
                id={`btn-margin-${value}`}
                className={`px-1.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  settings.margin === value
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Image Scaling */}
        <div>
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
            <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Image Fit Mode
          </label>
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            {(
              [
                ['fit', 'Fit Ratio'],
                ['fill', 'Fill Page'],
                ['stretch', 'Stretch'],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => updateSetting('scaling', value as ImageScaling)}
                id={`btn-scaling-${value}`}
                className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  settings.scaling === value
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Compression Quality */}
        <div>
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Compression Quality
          </label>
          <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            {(
              [
                ['original', 'Best'],
                ['high', 'High'],
                ['medium', 'Med'],
                ['low', 'Compact'],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => updateSetting('compression', value as ImageCompression)}
                id={`btn-compression-${value}`}
                className={`px-1.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  settings.compression === value
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Page Numbers Toggle */}
        <div className="flex flex-col justify-end">
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-1.5">
            <Hash className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            Page Numbering
          </label>
          <button
            type="button"
            onClick={() => updateSetting('showPageNumbers', !settings.showPageNumbers)}
            id="btn-toggle-page-numbers"
            className={`w-full py-2.5 px-3.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-colors ${
              settings.showPageNumbers
                ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                : 'border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
            }`}
          >
            <span>Add Footer "Page X of Y"</span>
            <span
              className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] text-white font-bold ${
                settings.showPageNumbers ? 'bg-blue-600' : 'bg-slate-400 dark:bg-slate-600'
              }`}
            >
              {settings.showPageNumbers ? '✓' : ''}
            </span>
          </button>
        </div>
      </div>

      {/* Output Filename & Primary Convert Button */}
      <div className="pt-4 border-t border-slate-200/80 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="w-full sm:w-auto flex-1 max-w-md">
          <label className="block text-xs font-bold text-slate-900 dark:text-slate-100 mb-1">
            Output PDF Filename
          </label>
          <div className="relative flex items-center">
            <input
              type="text"
              value={settings.filename}
              onChange={(e) => updateSetting('filename', e.target.value)}
              placeholder="Enter PDF filename"
              id="input-pdf-filename"
              className="w-full pl-3.5 pr-20 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            <span className="absolute right-10 text-xs font-medium text-slate-400 pointer-events-none">
              .pdf
            </span>
            <button
              type="button"
              onClick={handleAutoFilename}
              id="btn-auto-filename"
              className="absolute right-2.5 p-1 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
              title="Generate automatic timestamp filename"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={onConvert}
          disabled={totalImages === 0}
          id="btn-convert-pdf"
          className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-md shadow-blue-500/20 flex items-center justify-center gap-2.5 transition-all duration-200 disabled:opacity-50"
        >
          <FileCheck className="w-5 h-5" />
          <span>Convert {totalImages} {totalImages === 1 ? 'Page' : 'Pages'} to PDF</span>
        </button>
      </div>
    </div>
  );
};
