import React from 'react';
import { X, RotateCw, ZoomIn, ZoomOut } from 'lucide-react';
import { ImageItem } from '../../types/pdf';
import { formatBytes } from '../../utils/pdfGenerator';

interface ImagePreviewModalProps {
  image: ImageItem | null;
  onClose: () => void;
  onRotate?: (id: string) => void;
}

export const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({
  image,
  onClose,
  onRotate,
}) => {
  const [zoom, setZoom] = React.useState(1);

  if (!image) return null;

  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.25, 2.5));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.25, 0.5));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#111412]/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#1A1D1A] rounded-3xl border border-[#2D322C] overflow-hidden shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#2D322C] bg-[#1A1D1A] text-white">
          <div>
            <h3 className="text-sm font-semibold truncate max-w-md text-[#E2E6DF]">{image.name}</h3>
            <p className="text-xs text-[#9EA39B]">
              {image.width} × {image.height} px • {formatBytes(image.size)}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleZoomOut}
              id="btn-zoom-out"
              className="p-2 rounded-full bg-[#222622] hover:bg-[#2D322C] text-[#E2E6DF] border border-[#2D322C]"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono font-semibold text-[#9EA39B] px-1">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={handleZoomIn}
              id="btn-zoom-in"
              className="p-2 rounded-full bg-[#222622] hover:bg-[#2D322C] text-[#E2E6DF] border border-[#2D322C]"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>

            {onRotate && (
              <button
                onClick={() => onRotate(image.id)}
                id="btn-modal-rotate"
                className="p-2 rounded-full bg-[#222622] hover:bg-[#2D322C] text-[#E2E6DF] border border-[#2D322C]"
                title="Rotate 90°"
              >
                <RotateCw className="w-4 h-4 text-[#A8F0D3]" />
              </button>
            )}

            <button
              onClick={onClose}
              id="btn-close-preview"
              className="p-2 rounded-full bg-[#222622] hover:bg-red-900/40 text-[#E2E6DF] hover:text-red-400 border border-[#2D322C] ml-2"
              title="Close preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / Image Stage */}
        <div className="flex-1 overflow-auto p-6 flex items-center justify-center bg-[#111412] min-h-[350px]">
          <div
            style={{
              transform: `scale(${zoom}) rotate(${image.rotation % 360}deg)`,
              transition: 'transform 0.2s ease-out',
            }}
            className="max-w-full max-h-full flex items-center justify-center"
          >
            <img
              src={image.src}
              alt={image.name}
              className="max-h-[65vh] object-contain rounded-xl shadow-2xl border border-[#2D322C]"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
