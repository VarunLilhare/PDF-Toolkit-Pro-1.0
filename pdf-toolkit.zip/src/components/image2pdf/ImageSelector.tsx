import React, { useRef, useState } from 'react';
import { Upload, Image as ImageIcon, Sparkles, AlertCircle, Camera } from 'lucide-react';
import { ImageItem } from '../../types/pdf';

interface ImageSelectorProps {
  onImagesSelected: (newImages: ImageItem[]) => void;
  isLoading?: boolean;
}

// Sample high quality demo images for instant testing
const SAMPLE_IMAGES = [
  {
    name: 'Sample_Document_Page_1.jpg',
    url: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1000&q=80',
  },
  {
    name: 'Sample_Receipt_Scan.jpg',
    url: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=1000&q=80',
  },
  {
    name: 'Sample_Certificate.jpg',
    url: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=1000&q=80',
  },
];

export const ImageSelector: React.FC<ImageSelectorProps> = ({
  onImagesSelected,
  isLoading = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isProcessingSamples, setIsProcessingSamples] = useState(false);

  const processFiles = async (files: FileList | File[]) => {
    setErrorMessage(null);
    const validImageFiles: File[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        validImageFiles.push(file);
      }
    }

    if (validImageFiles.length === 0) {
      setErrorMessage('Please select valid image files (JPG, PNG, WEBP, GIF, BMP).');
      return;
    }

    const items: ImageItem[] = [];

    for (const file of validImageFiles) {
      try {
        const dataUrl = await readFileAsDataUrl(file);
        const { width, height } = await getImageDimensions(dataUrl);

        items.push({
          id: `img_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          file,
          src: dataUrl,
          name: file.name,
          size: file.size,
          width,
          height,
          rotation: 0,
        });
      } catch (err) {
        console.error('Error reading file', file.name, err);
      }
    }

    if (items.length > 0) {
      onImagesSelected(items);
    }
  };

  const readFileAsDataUrl = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  };

  const getImageDimensions = (
    src: string
  ): Promise<{ width: number; height: number }> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.width, height: img.height });
      img.onerror = () => resolve({ width: 800, height: 1100 });
      img.src = src;
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleLoadSamples = async () => {
    setIsProcessingSamples(true);
    setErrorMessage(null);
    try {
      const loadedItems: ImageItem[] = [];
      for (const sample of SAMPLE_IMAGES) {
        const response = await fetch(sample.url);
        const blob = await response.blob();
        const file = new File([blob], sample.name, { type: 'image/jpeg' });
        const dataUrl = await readFileAsDataUrl(file);
        const { width, height } = await getImageDimensions(dataUrl);

        loadedItems.push({
          id: `sample_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          file,
          src: dataUrl,
          name: sample.name,
          size: blob.size,
          width,
          height,
          rotation: 0,
        });
      }
      onImagesSelected(loadedItems);
    } catch (err) {
      console.error('Failed to load sample images', err);
      setErrorMessage('Could not load sample images. Please select your own local image files.');
    } finally {
      setIsProcessingSamples(false);
    }
  };

  return (
    <div className="w-full">
      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => e.target.files && processFiles(e.target.files)}
        multiple
        accept="image/jpeg,image/png,image/webp,image/gif,image/bmp"
        className="hidden"
        id="input-file-select"
      />

      <input
        type="file"
        ref={cameraInputRef}
        onChange={(e) => e.target.files && processFiles(e.target.files)}
        accept="image/*"
        capture="environment"
        className="hidden"
        id="input-camera-select"
      />

      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center transition-all duration-300 flex flex-col items-center justify-center min-h-[320px] backdrop-blur-md ${
          isDragging
            ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/40 scale-[0.99]'
            : 'border-slate-300 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 hover:border-blue-500 dark:hover:border-blue-400'
        }`}
      >
        <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-5 border border-blue-100 dark:border-blue-900/40">
          <Upload className="w-8 h-8 animate-bounce" />
        </div>

        <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">
          Select Images to Convert
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6 leading-relaxed">
          Drag & drop photos, camera scans, certificates or diagrams here, or select from your device. Supports JPG, PNG, WEBP, GIF, and BMP.
        </p>

        {errorMessage && (
          <div className="mb-6 px-4 py-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="flex flex-wrap justify-center gap-3 w-full max-w-sm">
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading || isProcessingSamples}
            id="btn-select-files"
            className="flex-1 min-w-[140px] px-6 py-3.5 rounded-full bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50"
          >
            <ImageIcon className="w-4 h-4" />
            <span>Browse Files</span>
          </button>

          <button
            onClick={() => cameraInputRef.current?.click()}
            disabled={isLoading || isProcessingSamples}
            id="btn-camera-capture"
            className="px-5 py-3.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 border border-slate-200 dark:border-slate-700"
            title="Take photo with camera"
          >
            <Camera className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span className="hidden sm:inline">Camera</span>
          </button>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-200/80 dark:border-slate-800/80 w-full max-w-md flex flex-col items-center">
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mb-3">
            Want to test immediately without uploading?
          </p>
          <button
            onClick={handleLoadSamples}
            disabled={isLoading || isProcessingSamples}
            id="btn-load-sample-images"
            className="px-4 py-2 rounded-full bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50 border border-blue-200/50 dark:border-blue-800/50"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>{isProcessingSamples ? 'Loading Samples...' : 'Load Sample Documents'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
