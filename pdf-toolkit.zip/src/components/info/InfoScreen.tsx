import React from 'react';
import { ShieldCheck, Zap, FileText, Lock, Cpu, HardDrive, CheckCircle2 } from 'lucide-react';

export const InfoScreen: React.FC = () => {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-fade-in pb-16">
      <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-200/80 dark:border-slate-800/80 p-6 sm:p-8 space-y-6 shadow-sm">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            Application Information & Specs
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            PDF Toolkit Pro • High-Performance Client-Side Document Processing Architecture
          </p>
        </div>

        {/* Highlight Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400">
              <ShieldCheck className="w-5 h-5" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">100% Client-Side Privacy</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Your sensitive documents never leave your browser. All image transformations, Word parsing, HTML layout calculations, and PDF binary encodings execute entirely on your device using Web API standards.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400">
              <Zap className="w-5 h-5" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Ultra Fast Performance</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Powered by high-throughput HTML5 Canvas rendering and Mammoth JS Word document parsing engines. Experience instant processing with zero network latency.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400">
              <FileText className="w-5 h-5" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Standard Compliant PDF Spec</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Produces valid <code className="bg-slate-200/60 dark:bg-slate-700/60 px-1 py-0.5 rounded text-[11px] font-mono">%PDF-1.4</code> binary header structures with cross-reference tables, page catalogs, vector margins, and automated footer page numbering.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-2">
            <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400">
              <HardDrive className="w-5 h-5" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Local IndexedDB Storage</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Generated PDF documents are safely stored in your browser's persistent IndexedDB storage engine. You can re-view, rename, download, or delete them anytime.
            </p>
          </div>
        </div>

        {/* Supported Capabilities List */}
        <div className="pt-4 border-t border-slate-200/80 dark:border-slate-800/80 space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Supported Formats & Operations
          </h3>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-500 dark:text-slate-400">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Image Formats: JPG, PNG, WebP, GIF, BMP</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Document Formats: DOCX (Office Open XML Word)</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Page Presets: A4, US Letter, US Legal</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Orientation: Portrait & Landscape</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Custom Margins: None, Small, Medium, Large</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Embedded PDF Viewer with zoom & multi-page navigation</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
