/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TopBar } from './components/common/TopBar';
import { HomeScreen } from './components/home/HomeScreen';
import { Word2PdfStudio } from './components/word2pdf/Word2PdfStudio';
import { ImageSelector } from './components/image2pdf/ImageSelector';
import { ImageGrid } from './components/image2pdf/ImageGrid';
import { PdfSettingsPanel } from './components/image2pdf/PdfSettingsPanel';
import { ImagePreviewModal } from './components/image2pdf/ImagePreviewModal';
import { ConversionProgressModal } from './components/image2pdf/ConversionProgressModal';
import { SuccessView } from './components/image2pdf/SuccessView';
import { PdfViewerModal } from './components/pdf/PdfViewerModal';
import { HistoryModal } from './components/history/HistoryModal';
import { BottomNav } from './components/common/BottomNav';
import { InfoScreen } from './components/info/InfoScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';

import {
  ImageItem,
  PdfSettings,
  PdfDocumentRecord,
  ConversionProgress,
  ViewMode,
} from './types/pdf';

import {
  generatePdfFromImages,
} from './utils/pdfGenerator';

import {
  savePdfToStorage,
  getAllPdfsFromStorage,
  renamePdfInStorage,
  deletePdfFromStorage,
} from './utils/storage';

import { AlertCircle } from 'lucide-react';

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('theme') === 'dark';
  });

  const [viewMode, setViewMode] = useState<ViewMode>('HOME');
  const [selectedImages, setSelectedImages] = useState<ImageItem[]>([]);
  const [previewImage, setPreviewImage] = useState<ImageItem | null>(null);

  const [pdfSettings, setPdfSettings] = useState<PdfSettings>({
    pageSize: 'a4',
    orientation: 'portrait',
    margin: 'small',
    scaling: 'fit',
    compression: 'high',
    showPageNumbers: false,
    filename: `IMG_PDF_${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`,
  });

  const [conversionProgress, setConversionProgress] = useState<ConversionProgress | null>(null);
  const [currentPdfRecord, setCurrentPdfRecord] = useState<PdfDocumentRecord | null>(null);
  const [activeViewerRecord, setActiveViewerRecord] = useState<PdfDocumentRecord | null>(null);

  const [historyRecords, setHistoryRecords] = useState<PdfDocumentRecord[]>([]);
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync Dark Mode class on <html>
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  // Load saved PDFs on mount
  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const records = await getAllPdfsFromStorage();
      setHistoryRecords(records);
    } catch (err) {
      console.error('Failed to load PDF history', err);
    }
  };

  const handleImagesSelected = (newImages: ImageItem[]) => {
    setSelectedImages((prev) => [...prev, ...newImages]);
    setViewMode('IMAGE2PDF');
  };

  const handleRotateImage = (id: string) => {
    setSelectedImages((prev) =>
      prev.map((img) =>
        img.id === id ? { ...img, rotation: (img.rotation + 90) % 360 } : img
      )
    );
    if (previewImage && previewImage.id === id) {
      setPreviewImage((prev) =>
        prev ? { ...prev, rotation: (prev.rotation + 90) % 360 } : null
      );
    }
  };

  const handleRemoveImage = (id: string) => {
    const updated = selectedImages.filter((img) => img.id !== id);
    setSelectedImages(updated);
  };

  const handleClearAll = () => {
    setSelectedImages([]);
  };

  const handleStartConversion = async () => {
    if (selectedImages.length === 0) {
      setErrorMessage('Please add at least one image before converting.');
      return;
    }

    setErrorMessage(null);
    setConversionProgress({
      status: 'preparing',
      currentStep: 0,
      totalSteps: selectedImages.length + 2,
      message: 'Initializing conversion...',
      percentage: 5,
    });

    try {
      const result = await generatePdfFromImages(
        selectedImages,
        pdfSettings,
        (progress) => setConversionProgress(progress)
      );

      const recordId = `pdf_${Date.now()}`;
      const savedRecord = await savePdfToStorage(
        recordId,
        pdfSettings.filename,
        result.arrayBuffer,
        result.pageCount,
        result.thumbnailUrl
      );

      setCurrentPdfRecord(savedRecord);
      setConversionProgress(null);
      setViewMode('SUCCESS');
      loadHistory();
    } catch (err: any) {
      console.error('PDF Conversion error:', err);
      setConversionProgress(null);
      setErrorMessage(err.message || 'An error occurred during PDF creation.');
    }
  };

  const handleWordConversionSuccess = async (record: PdfDocumentRecord) => {
    if (record.blobData) {
      const savedRecord = await savePdfToStorage(
        record.id,
        record.filename,
        record.blobData,
        record.pageCount,
        record.thumbnailUrl
      );
      setCurrentPdfRecord(savedRecord);
    } else {
      setCurrentPdfRecord(record);
    }
    setViewMode('SUCCESS');
    loadHistory();
  };

  const handleDownloadRecord = (record: PdfDocumentRecord) => {
    if (!record.blobUrl) return;
    const a = document.createElement('a');
    a.href = record.blobUrl;
    a.download = record.filename.endsWith('.pdf')
      ? record.filename
      : `${record.filename}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShareRecord = async (record: PdfDocumentRecord) => {
    if (!record.blobUrl) return;
    try {
      if (navigator.share) {
        const blob = new Blob([record.blobData || ''], { type: 'application/pdf' });
        const file = new File([blob], record.filename, { type: 'application/pdf' });
        await navigator.share({
          title: record.filename,
          files: [file],
        });
      } else {
        handleDownloadRecord(record);
      }
    } catch (err) {
      console.warn('Share not supported or cancelled', err);
      handleDownloadRecord(record);
    }
  };

  const handleRenameRecord = async (id: string, newFilename: string) => {
    await renamePdfInStorage(id, newFilename);
    if (currentPdfRecord && currentPdfRecord.id === id) {
      setCurrentPdfRecord((prev) => (prev ? { ...prev, filename: newFilename } : null));
    }
    loadHistory();
  };

  const handleDeleteRecord = async (id: string) => {
    await deletePdfFromStorage(id);
    if (currentPdfRecord && currentPdfRecord.id === id) {
      setCurrentPdfRecord(null);
      setViewMode('HOME');
    }
    loadHistory();
  };

  const handleResetToHome = () => {
    setSelectedImages([]);
    setCurrentPdfRecord(null);
    setViewMode('HOME');
  };

  // Determine top bar title and subtitle
  let topBarTitle = 'PDF Toolkit Pro';
  let topBarSubtitle = 'All Tools Dashboard';

  if (viewMode === 'IMAGE2PDF' || viewMode === 'STUDIO') {
    topBarTitle = 'Image → PDF Converter';
    topBarSubtitle = 'Photos & Scans';
  } else if (viewMode === 'WORD2PDF') {
    topBarTitle = 'Word → PDF Converter';
    topBarSubtitle = 'DOCX Documents';
  } else if (viewMode === 'SUCCESS') {
    topBarTitle = 'PDF Document Ready';
    topBarSubtitle = 'Conversion Complete';
  } else if (viewMode === 'INFO') {
    topBarTitle = 'Application Specs';
    topBarSubtitle = 'Privacy & Features';
  } else if (viewMode === 'SETTINGS') {
    topBarTitle = 'App Preferences';
    topBarSubtitle = 'Settings & Cache';
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white transition-colors duration-200 pb-16">
      {/* Top App Bar */}
      <TopBar
        title={topBarTitle}
        subtitle={topBarSubtitle}
        showBack={viewMode !== 'HOME'}
        onBack={() => setViewMode('HOME')}
        onOpenHistory={() => setShowHistoryModal(true)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        historyCount={historyRecords.length}
      />

      {/* Error Alert Toast */}
      {errorMessage && (
        <div className="max-w-4xl mx-auto mt-4 px-4 w-full">
          <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-semibold flex items-center justify-between shadow-md">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-5 h-5 shrink-0 text-red-500" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-500 hover:text-red-700 font-bold px-2 py-1"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 md:p-8 space-y-6 pb-20">
        {/* VIEW 1: HOME SCREEN */}
        {viewMode === 'HOME' && (
          <HomeScreen
            onNavigate={(view) => setViewMode(view)}
            recentPdfs={historyRecords}
            onOpenRecord={(rec) => setActiveViewerRecord(rec)}
            onOpenHistory={() => setShowHistoryModal(true)}
          />
        )}

        {/* VIEW 2: IMAGE TO PDF WORKSPACE */}
        {(viewMode === 'IMAGE2PDF' || viewMode === 'STUDIO') && (
          <div className="space-y-6 animate-fade-in">
            {selectedImages.length === 0 ? (
              <ImageSelector onImagesSelected={handleImagesSelected} />
            ) : (
              <>
                <ImageGrid
                  images={selectedImages}
                  onReorder={setSelectedImages}
                  onRotate={handleRotateImage}
                  onRemove={handleRemoveImage}
                  onPreview={(img) => setPreviewImage(img)}
                  onAddMore={() => {
                    const input = document.getElementById('input-file-select');
                    if (input) input.click();
                  }}
                  onClearAll={handleClearAll}
                />

                <PdfSettingsPanel
                  settings={pdfSettings}
                  onChange={setPdfSettings}
                  onConvert={handleStartConversion}
                  totalImages={selectedImages.length}
                />
              </>
            )}
          </div>
        )}

        {/* VIEW 3: WORD TO PDF WORKSPACE */}
        {viewMode === 'WORD2PDF' && (
          <Word2PdfStudio
            onSuccess={handleWordConversionSuccess}
            onBackToHome={() => setViewMode('HOME')}
          />
        )}

        {/* VIEW 4: SUCCESS CONFIRMATION */}
        {viewMode === 'SUCCESS' && currentPdfRecord && (
          <SuccessView
            record={currentPdfRecord}
            onOpenViewer={() => setActiveViewerRecord(currentPdfRecord)}
            onDownload={() => handleDownloadRecord(currentPdfRecord)}
            onShare={() => handleShareRecord(currentPdfRecord)}
            onRename={(newFilename) => handleRenameRecord(currentPdfRecord.id, newFilename)}
            onDelete={() => handleDeleteRecord(currentPdfRecord.id)}
            onReset={handleResetToHome}
          />
        )}

        {/* VIEW 5: INFO SCREEN */}
        {viewMode === 'INFO' && <InfoScreen />}

        {/* VIEW 6: SETTINGS SCREEN */}
        {viewMode === 'SETTINGS' && (
          <SettingsScreen
            darkMode={darkMode}
            onToggleDarkMode={() => setDarkMode(!darkMode)}
            historyCount={historyRecords.length}
            onHistoryCleared={() => loadHistory()}
          />
        )}
      </main>

      {/* Bottom Navigation Taskbar */}
      <BottomNav currentView={viewMode} onNavigate={(view) => setViewMode(view)} />

      {/* Image Zoom Preview Modal */}
      {previewImage && (
        <ImagePreviewModal
          image={previewImage}
          onClose={() => setPreviewImage(null)}
          onRotate={handleRotateImage}
        />
      )}

      {/* Conversion Progress Modal */}
      {conversionProgress && (
        <ConversionProgressModal
          progress={conversionProgress}
          onCancel={() => setConversionProgress(null)}
        />
      )}

      {/* Embedded PDF Viewer Modal */}
      {activeViewerRecord && (
        <PdfViewerModal
          record={activeViewerRecord}
          onClose={() => setActiveViewerRecord(null)}
          onDownload={() => handleDownloadRecord(activeViewerRecord)}
          onShare={() => handleShareRecord(activeViewerRecord)}
        />
      )}

      {/* History Modal */}
      {showHistoryModal && (
        <HistoryModal
          records={historyRecords}
          onClose={() => setShowHistoryModal(false)}
          onOpenRecord={(rec) => {
            setActiveViewerRecord(rec);
            setShowHistoryModal(false);
          }}
          onDownloadRecord={handleDownloadRecord}
          onShareRecord={handleShareRecord}
          onRenameRecord={handleRenameRecord}
          onDeleteRecord={handleDeleteRecord}
        />
      )}

      {/* Footer */}
      <footer className="mt-auto border-t border-[#E1E3DF] dark:border-[#2D322C] py-6 px-4 bg-white/50 dark:bg-[#111412]/50 text-center text-xs text-[#747972] dark:text-[#9EA39B]">
        <p>PDF Toolkit Pro • Client-Side Image & Word to PDF Conversion Engine</p>
      </footer>
    </div>
  );
}
