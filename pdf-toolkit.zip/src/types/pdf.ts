export type PageSize = 'a4' | 'letter' | 'legal' | 'fit';
export type PageOrientation = 'auto' | 'portrait' | 'landscape';
export type PageMargin = 'none' | 'small' | 'medium' | 'large';
export type ImageScaling = 'fit' | 'fill' | 'stretch';
export type ImageCompression = 'original' | 'high' | 'medium' | 'low';

export interface ImageItem {
  id: string;
  file?: File;
  src: string; // Base64 or Blob URL
  name: string;
  size: number;
  width: number;
  height: number;
  rotation: number; // 0, 90, 180, 270
}

export interface PdfSettings {
  pageSize: PageSize;
  orientation: PageOrientation;
  margin: PageMargin;
  scaling: ImageScaling;
  compression: ImageCompression;
  showPageNumbers: boolean;
  filename: string;
}

export interface WordSettings {
  pageSize: 'a4' | 'letter' | 'legal';
  orientation: 'portrait' | 'landscape';
  margin: PageMargin;
  showPageNumbers: boolean;
  filename: string;
}

export interface WordDocumentInfo {
  id: string;
  file?: File;
  name: string;
  size: number;
  wordCount: number;
  paragraphCount: number;
  imageCount: number;
  htmlContent: string;
  rawText: string;
  isPasswordProtected?: boolean;
  isLegacyDoc?: boolean;
}

export interface PdfDocumentRecord {
  id: string;
  filename: string;
  sizeBytes: number;
  pageCount: number;
  createdAt: number;
  blobUrl?: string;
  blobData?: ArrayBuffer;
  thumbnailUrl?: string;
  sourceType?: 'image' | 'word';
}

export interface ConversionProgress {
  status: 'idle' | 'preparing' | 'rendering' | 'validating' | 'saving' | 'completed' | 'error';
  currentStep: number;
  totalSteps: number;
  message: string;
  percentage: number;
}

export interface PdfGenerationResult {
  arrayBuffer: ArrayBuffer;
  blobUrl: string;
  sizeBytes: number;
  pageCount: number;
  isValid: boolean;
  thumbnailUrl: string;
}


export type ViewMode = 'HOME' | 'IMAGE2PDF' | 'WORD2PDF' | 'STUDIO' | 'SUCCESS' | 'VIEWER' | 'INFO' | 'SETTINGS';

export type ToolCategory = 'convert-to-pdf' | 'convert-from-pdf' | 'edit-organize' | 'security-utility';

export interface ToolItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  category: ToolCategory;
  isActive: boolean;
  badge?: string;
  viewMode?: ViewMode;
}

