import { PdfDocumentRecord } from '../types/pdf';

const DB_NAME = 'PdfToolkitDB';
const DB_VERSION = 1;
const STORE_NAME = 'pdf_documents';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function savePdfToStorage(
  id: string,
  filename: string,
  pdfArrayBuffer: ArrayBuffer,
  pageCount: number,
  thumbnailUrl?: string
): Promise<PdfDocumentRecord> {
  const db = await openDatabase();
  const record: PdfDocumentRecord = {
    id,
    filename,
    sizeBytes: pdfArrayBuffer.byteLength,
    pageCount,
    createdAt: Date.now(),
    blobData: pdfArrayBuffer,
    thumbnailUrl,
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(record);

    req.onsuccess = () => {
      const blob = new Blob([pdfArrayBuffer], { type: 'application/pdf' });
      record.blobUrl = URL.createObjectURL(blob);
      resolve(record);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function getAllPdfsFromStorage(): Promise<PdfDocumentRecord[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const index = store.index('createdAt');
      const req = index.openCursor(null, 'prev');
      const results: PdfDocumentRecord[] = [];

      req.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest<IDBCursorWithValue>).result;
        if (cursor) {
          const val = cursor.value as PdfDocumentRecord;
          if (val.blobData) {
            const blob = new Blob([val.blobData], { type: 'application/pdf' });
            val.blobUrl = URL.createObjectURL(blob);
          }
          results.push(val);
          cursor.continue();
        } else {
          resolve(results);
        }
      };

      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to load PDFs from IndexedDB', err);
    return [];
  }
}

export async function renamePdfInStorage(id: string, newFilename: string): Promise<boolean> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);

    getReq.onsuccess = () => {
      const record = getReq.result as PdfDocumentRecord;
      if (!record) {
        resolve(false);
        return;
      }
      record.filename = newFilename.endsWith('.pdf') ? newFilename : `${newFilename}.pdf`;
      const putReq = store.put(record);
      putReq.onsuccess = () => resolve(true);
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function deletePdfFromStorage(id: string): Promise<boolean> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);

    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

export async function clearAllPdfsFromStorage(): Promise<boolean> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.clear();

    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}
