import { jsPDF } from 'jspdf';
import { ImageItem, PdfSettings, ConversionProgress } from '../types/pdf';

// Paper dimensions in mm [width, height]
const PAGE_DIMENSIONS_MM: Record<string, [number, number]> = {
  a4: [210, 297],
  letter: [215.9, 279.4],
  legal: [215.9, 355.6],
};

const MARGIN_MM: Record<string, number> = {
  none: 0,
  small: 5,
  medium: 12,
  large: 20,
};

const QUALITY_FACTOR: Record<string, number> = {
  original: 0.95,
  high: 0.85,
  medium: 0.70,
  low: 0.50,
};

/**
 * Process image with rotation and quality adjustments using HTML Canvas
 */
async function processImageCanvas(
  item: ImageItem,
  compression: string
): Promise<{ dataUrl: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const rotation = item.rotation % 360;
      const isRotated90 = rotation === 90 || rotation === 270;

      let sourceWidth = img.naturalWidth || img.width;
      let sourceHeight = img.naturalHeight || img.height;

      // Downscale if low/medium compression requested to save RAM and PDF size
      let maxDim = 2500;
      if (compression === 'low') maxDim = 1200;
      else if (compression === 'medium') maxDim = 1800;

      if (sourceWidth > maxDim || sourceHeight > maxDim) {
        const ratio = Math.min(maxDim / sourceWidth, maxDim / sourceHeight);
        sourceWidth = Math.round(sourceWidth * ratio);
        sourceHeight = Math.round(sourceHeight * ratio);
      }

      const canvas = document.createElement('canvas');
      if (isRotated90) {
        canvas.width = sourceHeight;
        canvas.height = sourceWidth;
      } else {
        canvas.width = sourceWidth;
        canvas.height = sourceHeight;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Failed to create canvas context'));
        return;
      }

      ctx.save();
      // Move to center of canvas
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);

      // Draw image offset from center
      ctx.drawImage(
        img,
        -sourceWidth / 2,
        -sourceHeight / 2,
        sourceWidth,
        sourceHeight
      );
      ctx.restore();

      const quality = QUALITY_FACTOR[compression] ?? 0.85;
      const dataUrl = canvas.toDataURL('image/jpeg', quality);

      resolve({
        dataUrl,
        width: canvas.width,
        height: canvas.height,
      });
    };

    img.onerror = () => {
      reject(new Error(`Failed to load image: ${item.name}`));
    };

    img.src = item.src;
  });
}

export interface PdfGenerationResult {
  arrayBuffer: ArrayBuffer;
  blobUrl: string;
  sizeBytes: number;
  pageCount: number;
  isValid: boolean;
  thumbnailUrl: string;
}

/**
 * Generate PDF from array of images
 */
export async function generatePdfFromImages(
  images: ImageItem[],
  settings: PdfSettings,
  onProgress?: (progress: ConversionProgress) => void
): Promise<PdfGenerationResult> {
  if (!images || images.length === 0) {
    throw new Error('No images selected for PDF creation.');
  }

  const totalSteps = images.length + 2; // Images + Render + Validate
  onProgress?.({
    status: 'preparing',
    currentStep: 0,
    totalSteps,
    message: 'Initializing PDF document...',
    percentage: 5,
  });

  let doc: jsPDF | null = null;
  let firstPageThumbnail = '';

  for (let i = 0; i < images.length; i++) {
    const item = images[i];
    const step = i + 1;
    const progressPct = Math.round((step / totalSteps) * 85);

    onProgress?.({
      status: 'rendering',
      currentStep: step,
      totalSteps,
      message: `Processing image ${step} of ${images.length}: ${item.name}`,
      percentage: progressPct,
    });

    const processed = await processImageCanvas(item, settings.compression);

    if (i === 0) {
      firstPageThumbnail = processed.dataUrl;
    }

    // Determine Page Width and Height in mm
    let pageWidthMM: number;
    let pageHeightMM: number;

    if (settings.pageSize === 'fit') {
      // Fit page exactly to image dimensions (converting px to mm at 72dpi equivalent)
      const pxToMm = 0.264583;
      pageWidthMM = processed.width * pxToMm;
      pageHeightMM = processed.height * pxToMm;
    } else {
      const standardDim = PAGE_DIMENSIONS_MM[settings.pageSize] || PAGE_DIMENSIONS_MM.a4;
      pageWidthMM = standardDim[0];
      pageHeightMM = standardDim[1];
    }

    // Determine orientation adjustment if not 'fit'
    let orientationParam: 'p' | 'l' = 'p';
    if (settings.orientation === 'landscape') {
      orientationParam = 'l';
      if (pageWidthMM < pageHeightMM) {
        const temp = pageWidthMM;
        pageWidthMM = pageHeightMM;
        pageHeightMM = temp;
      }
    } else if (settings.orientation === 'portrait') {
      orientationParam = 'p';
      if (pageWidthMM > pageHeightMM) {
        const temp = pageWidthMM;
        pageWidthMM = pageHeightMM;
        pageHeightMM = temp;
      }
    } else if (settings.orientation === 'auto') {
      // Auto orientation: adapt page aspect ratio to image aspect ratio
      if (processed.width > processed.height) {
        orientationParam = 'l';
        if (pageWidthMM < pageHeightMM) {
          const temp = pageWidthMM;
          pageWidthMM = pageHeightMM;
          pageHeightMM = temp;
        }
      } else {
        orientationParam = 'p';
        if (pageWidthMM > pageHeightMM) {
          const temp = pageWidthMM;
          pageWidthMM = pageHeightMM;
          pageHeightMM = temp;
        }
      }
    }

    // Create jsPDF instance on first image
    if (!doc) {
      doc = new jsPDF({
        orientation: orientationParam,
        unit: 'mm',
        format: settings.pageSize === 'fit' ? [pageWidthMM, pageHeightMM] : settings.pageSize,
        compress: true,
      });
    } else {
      doc.addPage(
        settings.pageSize === 'fit' ? [pageWidthMM, pageHeightMM] : settings.pageSize,
        orientationParam
      );
    }

    // Calculate margins and printable area
    const marginMM = MARGIN_MM[settings.margin] ?? 0;
    const printableWidth = Math.max(1, pageWidthMM - marginMM * 2);
    const printableHeight = Math.max(1, pageHeightMM - marginMM * 2);

    // Calculate placement X, Y, W, H based on scaling mode
    let targetW = printableWidth;
    let targetH = printableHeight;
    let xMM = marginMM;
    let yMM = marginMM;

    const imgAspect = processed.width / processed.height;
    const printableAspect = printableWidth / printableHeight;

    if (settings.scaling === 'fit') {
      // Maintain aspect ratio, fit inside printable bounds
      if (imgAspect > printableAspect) {
        targetW = printableWidth;
        targetH = printableWidth / imgAspect;
        xMM = marginMM;
        yMM = marginMM + (printableHeight - targetH) / 2;
      } else {
        targetH = printableHeight;
        targetW = printableHeight * imgAspect;
        xMM = marginMM + (printableWidth - targetW) / 2;
        yMM = marginMM;
      }
    } else if (settings.scaling === 'fill') {
      // Scale to cover printable area
      if (imgAspect > printableAspect) {
        targetH = printableHeight;
        targetW = printableHeight * imgAspect;
        xMM = marginMM - (targetW - printableWidth) / 2;
        yMM = marginMM;
      } else {
        targetW = printableWidth;
        targetH = printableWidth / imgAspect;
        xMM = marginMM;
        yMM = marginMM - (targetH - printableHeight) / 2;
      }
    } else if (settings.scaling === 'stretch') {
      // Stretch to fill exactly
      targetW = printableWidth;
      targetH = printableHeight;
      xMM = marginMM;
      yMM = marginMM;
    }

    // Add Image to PDF page
    doc.addImage(
      processed.dataUrl,
      'JPEG',
      xMM,
      yMM,
      targetW,
      targetH,
      undefined,
      'FAST'
    );

    // Footer page number option
    if (settings.showPageNumbers) {
      doc.setFontSize(9);
      doc.setTextColor(100, 100, 100);
      const text = `Page ${step} of ${images.length}`;
      doc.text(text, pageWidthMM / 2, pageHeightMM - Math.max(3, marginMM / 2), {
        align: 'center',
      });
    }
  }

  if (!doc) {
    throw new Error('PDF document creation failed.');
  }

  onProgress?.({
    status: 'validating',
    currentStep: totalSteps - 1,
    totalSteps,
    message: 'Validating PDF document structure...',
    percentage: 90,
  });

  const arrayBuffer = doc.output('arraybuffer');
  const sizeBytes = arrayBuffer.byteLength;

  // Validate PDF magic header '%PDF-'
  const uint8 = new Uint8Array(arrayBuffer);
  const pdfHeader = String.fromCharCode(...uint8.subarray(0, 5));
  const isValid = pdfHeader === '%PDF-' && sizeBytes > 100;

  if (!isValid) {
    throw new Error('PDF Validation failed: Invalid header signature or zero length.');
  }

  const blob = new Blob([arrayBuffer], { type: 'application/pdf' });
  const blobUrl = URL.createObjectURL(blob);

  onProgress?.({
    status: 'completed',
    currentStep: totalSteps,
    totalSteps,
    message: 'PDF conversion completed successfully!',
    percentage: 100,
  });

  return {
    arrayBuffer,
    blobUrl,
    sizeBytes,
    pageCount: images.length,
    isValid,
    thumbnailUrl: firstPageThumbnail,
  };
}

/**
 * Format bytes to readable string (e.g., 2.4 MB)
 */
export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
