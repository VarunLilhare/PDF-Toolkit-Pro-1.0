import mammoth from 'mammoth';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { WordDocumentInfo, WordSettings, ConversionProgress, PdfGenerationResult } from '../types/pdf';

// Paper dimensions in mm [width, height]
const PAGE_DIMENSIONS_MM: Record<string, [number, number]> = {
  a4: [210, 297],
  letter: [215.9, 279.4],
  legal: [215.9, 355.6],
};

const MARGIN_MM: Record<string, number> = {
  none: 0,
  small: 8,
  medium: 15,
  large: 22,
};

/**
 * Validates file signature and parses DOCX content into HTML and text
 */
export async function validateAndParseWordFile(file: File): Promise<WordDocumentInfo> {
  if (!file) {
    throw new Error('No file provided for validation.');
  }

  if (file.size === 0) {
    throw new Error('The selected document is empty (0 bytes). Please select a valid Word file.');
  }

  const fileNameLower = file.name.toLowerCase();
  const isDocxExt = fileNameLower.endsWith('.docx');
  const isDocExt = fileNameLower.endsWith('.doc');

  if (!isDocxExt && !isDocExt) {
    throw new Error(
      `Unsupported file extension: "${file.name}". Please upload a Microsoft Word file (.docx or .doc).`
    );
  }

  const arrayBuffer = await file.arrayBuffer();
  const uint8 = new Uint8Array(arrayBuffer);

  // Check magic headers
  // ZIP archive header (DOCX): PK\x03\x04 (0x50, 0x4B, 0x03, 0x04)
  const isZipHeader =
    uint8[0] === 0x50 && uint8[1] === 0x4b && uint8[2] === 0x03 && uint8[3] === 0x04;

  // OLE Compound File header (Legacy DOC): 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1
  const isOleHeader =
    uint8[0] === 0xd0 && uint8[1] === 0xcf && uint8[2] === 0x11 && uint8[3] === 0xe0;

  if (isDocExt || isOleHeader) {
    // Attempt fallback or notify user
    return {
      id: `word_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      file,
      name: file.name,
      size: file.size,
      wordCount: 0,
      paragraphCount: 0,
      imageCount: 0,
      htmlContent: `<div style="padding: 20px; font-family: sans-serif; text-align: center;">
        <h3 style="color: #b91c1c;">Legacy Word Format (.doc) Detected</h3>
        <p>This file is stored in legacy Word 97-2003 binary format. For optimal formatting precision, tables, and images, convert to <strong>.docx</strong> in Word/Google Docs.</p>
      </div>`,
      rawText: 'Legacy Word Document (.doc)',
      isLegacyDoc: true,
    };
  }

  if (!isZipHeader) {
    throw new Error(
      'File validation failed: The file structure does not match a valid Microsoft Word XML document (.docx).'
    );
  }

  // Check for password protection / encrypted package stream inside zip header
  const decoder = new TextDecoder('utf-8', { fatal: false });
  const fileContentHead = decoder.decode(uint8.subarray(0, Math.min(uint8.length, 4096)));
  if (fileContentHead.includes('EncryptedPackage') || fileContentHead.includes('EncryptionInfo')) {
    throw new Error(
      'This Word document is password-protected or encrypted. Please remove password protection before converting to PDF.'
    );
  }

  // Parse DOCX via Mammoth
  try {
    const result = await mammoth.convertToHtml(
      { arrayBuffer },
      {
        styleMap: [
          "p[style-name='Heading 1'] => h1:fresh",
          "p[style-name='Heading 2'] => h2:fresh",
          "p[style-name='Heading 3'] => h3:fresh",
          "p[style-name='Title'] => h1.title:fresh",
          "p[style-name='Subtitle'] => p.subtitle:fresh",
        ],
      }
    );

    const rawTextResult = await mammoth.extractRawText({ arrayBuffer });
    const rawText = rawTextResult.value || '';
    const htmlContent = result.value || '';

    // Calculate document statistics
    const words = rawText.trim() ? rawText.trim().split(/\s+/).length : 0;
    const paragraphs = rawText
      .split(/\n+/)
      .filter((p) => p.trim().length > 0).length;

    // Count images embedded in HTML
    const imgMatches = htmlContent.match(/<img /g);
    const imageCount = imgMatches ? imgMatches.length : 0;

    if (words === 0 && paragraphs === 0 && imageCount === 0) {
      throw new Error(
        'The document appears to be empty or contains no readable text/images.'
      );
    }

    return {
      id: `word_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      file,
      name: file.name,
      size: file.size,
      wordCount: words,
      paragraphCount: paragraphs,
      imageCount,
      htmlContent,
      rawText,
    };
  } catch (err: any) {
    if (err.message && err.message.includes('password')) {
      throw new Error(
        'The document is password protected. Please unlock it in Microsoft Word first.'
      );
    }
    throw new Error(
      `Corrupted or invalid Word document: ${err.message || 'Failed to parse .docx file structure.'}`
    );
  }
}

/**
 * Converts Word document info into a styled PDF document using html2canvas & jsPDF
 */
export async function generatePdfFromWord(
  docInfo: WordDocumentInfo,
  settings: WordSettings,
  onProgress?: (progress: ConversionProgress) => void
): Promise<PdfGenerationResult> {
  const totalSteps = 4;

  onProgress?.({
    status: 'preparing',
    currentStep: 1,
    totalSteps,
    message: 'Preparing document layout & page styles...',
    percentage: 15,
  });

  // Calculate paper dimensions in mm
  const standardDim = PAGE_DIMENSIONS_MM[settings.pageSize] || PAGE_DIMENSIONS_MM.a4;
  let pageWidthMM = standardDim[0];
  let pageHeightMM = standardDim[1];

  if (settings.orientation === 'landscape') {
    pageWidthMM = standardDim[1];
    pageHeightMM = standardDim[0];
  }

  const marginMM = MARGIN_MM[settings.margin] ?? 15;

  // Create temporary offscreen container for rendering
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.top = '-9999px';
  container.style.width = `${Math.round(pageWidthMM * 3.779528)}px`; // mm to px at 96 DPI
  container.style.backgroundColor = '#FFFFFF';
  container.style.color = '#111827';
  container.style.padding = `${Math.round(marginMM * 3.779528)}px`;
  container.style.boxSizing = 'border-box';
  container.style.fontFamily = `'Liberation Sans', 'Arial', 'Helvetica', sans-serif`;
  container.style.lineHeight = '1.6';
  container.style.fontSize = '14px';

  // Apply rich document typography and table styles
  const styledHtml = `
    <style>
      h1 { font-size: 24px; font-weight: 700; color: #1e293b; margin-top: 18px; margin-bottom: 12px; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; }
      h2 { font-size: 18px; font-weight: 600; color: #334155; margin-top: 14px; margin-bottom: 8px; }
      h3 { font-size: 15px; font-weight: 600; color: #475569; margin-top: 12px; margin-bottom: 6px; }
      p { margin-bottom: 10px; text-align: justify; }
      ul, ol { margin-top: 6px; margin-bottom: 10px; padding-left: 24px; }
      li { margin-bottom: 4px; }
      table { width: 100%; border-collapse: collapse; margin-top: 12px; margin-bottom: 16px; font-size: 13px; }
      th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
      th { background-color: #f1f5f9; font-weight: 600; color: #1e293b; }
      tr:nth-child(even) { background-color: #f8fafc; }
      img { max-width: 100%; height: auto; display: block; margin: 12px auto; border-radius: 4px; }
      blockquote { border-left: 4px solid #006C4C; padding-left: 12px; margin: 12px 0; color: #475569; italic: true; }
    </style>
    <div>${docInfo.htmlContent}</div>
  `;

  container.innerHTML = styledHtml;
  document.body.appendChild(container);

  onProgress?.({
    status: 'rendering',
    currentStep: 2,
    totalSteps,
    message: 'Rendering formatted text, tables, and media...',
    percentage: 45,
  });

  // Render container to high-DPI canvas
  const canvas = await html2canvas(container, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#FFFFFF',
  });

  // Remove container from DOM
  document.body.removeChild(container);

  onProgress?.({
    status: 'rendering',
    currentStep: 3,
    totalSteps,
    message: 'Compiling PDF pages with margins & page numbers...',
    percentage: 75,
  });

  const pdf = new jsPDF({
    orientation: settings.orientation === 'landscape' ? 'l' : 'p',
    unit: 'mm',
    format: settings.pageSize,
    compress: true,
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.88);
  const imgWidth = pageWidthMM;
  const pageHeightPx = Math.round((canvas.width * pageHeightMM) / pageWidthMM);
  let totalHeightPx = canvas.height;
  let heightLeftPx = totalHeightPx;
  let pageIndex = 0;

  // Render full canvas across pages
  while (heightLeftPx > 0) {
    if (pageIndex > 0) {
      pdf.addPage(settings.pageSize, settings.orientation === 'landscape' ? 'l' : 'p');
    }

    // Slice canvas section for current page
    const pageCanvas = document.createElement('canvas');
    pageCanvas.width = canvas.width;
    pageCanvas.height = Math.min(pageHeightPx, heightLeftPx);

    const ctx = pageCanvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
      ctx.drawImage(
        canvas,
        0,
        pageIndex * pageHeightPx,
        canvas.width,
        pageCanvas.height,
        0,
        0,
        canvas.width,
        pageCanvas.height
      );
    }

    const pageImgData = pageCanvas.toDataURL('image/jpeg', 0.88);
    const sliceHeightMM = (pageCanvas.height * pageWidthMM) / canvas.width;

    pdf.addImage(pageImgData, 'JPEG', 0, 0, pageWidthMM, sliceHeightMM);

    // Optional page numbering
    if (settings.showPageNumbers) {
      pdf.setFontSize(9);
      pdf.setTextColor(120, 120, 120);
      const totalEstimatedPages = Math.ceil(totalHeightPx / pageHeightPx);
      pdf.text(
        `Page ${pageIndex + 1} of ${totalEstimatedPages}`,
        pageWidthMM / 2,
        pageHeightMM - 4,
        { align: 'center' }
      );
    }

    heightLeftPx -= pageHeightPx;
    pageIndex++;
  }

  // First page thumbnail
  const thumbnailCanvas = document.createElement('canvas');
  thumbnailCanvas.width = 240;
  thumbnailCanvas.height = Math.round((240 * pageHeightMM) / pageWidthMM);
  const tCtx = thumbnailCanvas.getContext('2d');
  if (tCtx) {
    tCtx.fillStyle = '#FFFFFF';
    tCtx.fillRect(0, 0, thumbnailCanvas.width, thumbnailCanvas.height);
    tCtx.drawImage(canvas, 0, 0, canvas.width, Math.min(pageHeightPx, canvas.height), 0, 0, thumbnailCanvas.width, thumbnailCanvas.height);
  }
  const thumbnailUrl = thumbnailCanvas.toDataURL('image/jpeg', 0.75);

  onProgress?.({
    status: 'validating',
    currentStep: 4,
    totalSteps,
    message: 'Validating generated PDF signature...',
    percentage: 92,
  });

  const arrayBuffer = pdf.output('arraybuffer');
  const sizeBytes = arrayBuffer.byteLength;

  // Validate PDF magic header '%PDF-'
  const uint8 = new Uint8Array(arrayBuffer);
  const pdfHeader = String.fromCharCode(...uint8.subarray(0, 5));
  const isValid = pdfHeader === '%PDF-' && sizeBytes > 100;

  if (!isValid) {
    throw new Error('PDF Validation failed: Output file header signature invalid.');
  }

  const blob = new Blob([arrayBuffer], { type: 'application/pdf' });
  const blobUrl = URL.createObjectURL(blob);

  onProgress?.({
    status: 'completed',
    currentStep: totalSteps,
    totalSteps,
    message: 'Word to PDF conversion completed!',
    percentage: 100,
  });

  return {
    arrayBuffer,
    blobUrl,
    sizeBytes,
    pageCount: Math.max(1, pageIndex),
    isValid,
    thumbnailUrl,
  };
}

/**
 * Creates a sample Word document metadata object for instant testing
 */
export function getSampleWordDocument(): WordDocumentInfo {
  const sampleHtml = `
    <h1>Executive Project Summary & Status Report</h1>
    <p><strong>Prepared for:</strong> Global Operations Team & Key Stakeholders</p>
    <p><strong>Date:</strong> July 30, 2026 | <strong>Status:</strong> Approved for Release</p>
    <hr />
    <h2>1. Executive Overview</h2>
    <p>This report presents the complete technical architecture and user experience roadmap for the unified <strong>PDF Toolkit Pro</strong>. The platform delivers secure, client-side document processing directly within the browser, eliminating data privacy risks associated with cloud file transfers.</p>
    
    <h2>2. Key Accomplishments</h2>
    <ul>
      <li><strong>100% Client-Side Privacy:</strong> All document transformations occur locally using Web APIs.</li>
      <li><strong>Multi-Format Converter Engine:</strong> Seamlessly process Image files (JPG, PNG, WEBP) and Word documents (DOCX).</li>
      <li><strong>Material Design 3 Interface:</strong> A clean, responsive dashboard designed for desktop and mobile workflows.</li>
    </ul>

    <h2>3. System Performance Metrics</h2>
    <table>
      <thead>
        <tr>
          <th>Metric</th>
          <th>Target</th>
          <th>Achieved</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Processing Speed</td>
          <td>&lt; 2.5s</td>
          <td>1.1s</td>
          <td>Optimal</td>
        </tr>
        <tr>
          <td>Memory Efficiency</td>
          <td>&lt; 50 MB</td>
          <td>22 MB</td>
          <td>Optimal</td>
        </tr>
        <tr>
          <td>PDF Compliance</td>
          <td>%PDF-1.7</td>
          <td>100% Valid</td>
          <td>Verified</td>
        </tr>
      </tbody>
    </table>

    <blockquote>
      "Privacy and speed are not mutually exclusive. By processing files directly in the client runtime, we achieve zero server latency and total data sovereignty."
    </blockquote>

    <h2>4. Conclusion & Next Steps</h2>
    <p>The system is ready for immediate deployment. Users can export, share, or store generated PDF files with full confidence in document fidelity and security.</p>
  `;

  const sampleRawText = `Executive Project Summary & Status Report
Prepared for: Global Operations Team & Key Stakeholders
Date: July 30, 2026 | Status: Approved for Release

1. Executive Overview
This report presents the complete technical architecture and user experience roadmap for the unified PDF Toolkit Pro. The platform delivers secure, client-side document processing directly within the browser, eliminating data privacy risks associated with cloud file transfers.

2. Key Accomplishments
- 100% Client-Side Privacy: All document transformations occur locally using Web APIs.
- Multi-Format Converter Engine: Seamlessly process Image files (JPG, PNG, WEBP) and Word documents (DOCX).
- Material Design 3 Interface: A clean, responsive dashboard designed for desktop and mobile workflows.

3. System Performance Metrics
Metric Target Achieved Status
Processing Speed < 2.5s 1.1s Optimal
Memory Efficiency < 50 MB 22 MB Optimal
PDF Compliance %PDF-1.7 100% Valid Verified

Conclusion & Next Steps
The system is ready for immediate deployment. Users can export, share, or store generated PDF files with full confidence in document fidelity and security.`;

  return {
    id: `sample_doc_${Date.now()}`,
    name: 'Sample_Business_Report.docx',
    size: 45200,
    wordCount: 220,
    paragraphCount: 12,
    imageCount: 0,
    htmlContent: sampleHtml,
    rawText: sampleRawText,
  };
}
